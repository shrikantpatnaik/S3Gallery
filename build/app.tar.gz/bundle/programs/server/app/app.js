var require = meteorInstall({"imports":{"api":{"albums.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// imports/api/albums.js                                                                    //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
module.export({
  Albums: () => Albums
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let publishPagination;
module.watch(require("meteor/kurounin:pagination"), {
  publishPagination(v) {
    publishPagination = v;
  }

}, 2);
const Albums = new Mongo.Collection('albums');
module.exportDefault(Albums);

if (Meteor.isServer) {
  publishPagination(Albums);
}
//////////////////////////////////////////////////////////////////////////////////////////////

},"aws.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// imports/api/aws.js                                                                       //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let AWS;
module.watch(require("meteor/peerlibrary:aws-sdk"), {
  AWS(v) {
    AWS = v;
  }

}, 1);
let s3ls;
module.watch(require("s3-ls"), {
  default(v) {
    s3ls = v;
  }

}, 2);

let _;

module.watch(require("lodash"), {
  default(v) {
    _ = v;
  }

}, 3);
let exifToolBin;
module.watch(require("dist-exiftool"), {
  default(v) {
    exifToolBin = v;
  }

}, 4);
let Exif;
module.watch(require("simple-exiftool"), {
  default(v) {
    Exif = v;
  }

}, 5);
let rp;
module.watch(require("request-promise"), {
  default(v) {
    rp = v;
  }

}, 6);
let Albums;
module.watch(require("./albums.js"), {
  Albums(v) {
    Albums = v;
  }

}, 7);
let Photos;
module.watch(require("./photos.js"), {
  Photos(v) {
    Photos = v;
  }

}, 8);

if (!Meteor.settings.AWS) {
  throw new Meteor.Error('AWS Settings must be specified');
}

const bucketName = Meteor.settings.AWS.s3BucketName;
const mainFolder = Meteor.settings.AWS.s3BucketMainFolder;
AWS.config.update({
  accessKeyId: Meteor.settings.AWS.accessKeyId,
  secretAccessKey: Meteor.settings.AWS.secretAccessKey
});
const s3 = new AWS.S3();
const lister = s3ls({
  bucket: bucketName,
  s3
});
const params = {
  Bucket: bucketName
};

function getEXIFFromBinary(data) {
  return new Promise(function (resolve, reject) {
    Exif(data, {
      binary: exifToolBin,
      args: ['-json', '-s', '-iptc:all', '-exif:all']
    }, (error, metadata) => {
      if (error) {
        reject(error);
      } else {
        const keysToExclude = ['ThumbnailOffset', 'ThumbnailLength', 'ThumbnailImage'];
        resolve(_.omit(metadata, keysToExclude));
      }
    });
  });
}

function getExifDataAsync(photo) {
  return Promise.asyncApply(() => {
    try {
      const url = encodeURI(`http://${Meteor.settings.public.photosBaseUrl}/${photo.key}`);
      const response = Promise.await(rp({
        uri: url,
        encoding: null
      }));
      const tags = Promise.await(getEXIFFromBinary(response));
      return tags;
    } catch (err) {
      return null;
    }
  });
}

function insertPhotoIfDoesntExist(key, albumId) {
  return Promise.asyncApply(() => {
    const photoParams = {
      key,
      albumId
    };
    let photo = Photos.findOne(photoParams);

    if (!photo) {
      const newId = Photos.insert(photoParams);
      photo = Photos.findOne(newId);
    }

    if (!photo.metadata) {
      const exifData = Promise.await(getExifDataAsync(photo));
      Photos.update(photo._id, {
        $set: {
          metadata: exifData
        }
      });
    }
  });
}

function insertKeysIntoAlbum(s3params, albumId) {
  const data = s3.listObjectsV2Sync(s3params);

  _.forEach(data.Contents, function (object) {
    if (Meteor.settings.public.AWS.s3LowQualityFolderName) {
      if (_.includes(object.Key, Meteor.settings.public.AWS.s3LowQualityFolderName)) {
        insertPhotoIfDoesntExist(object.Key, albumId);
      }
    } else {
      insertPhotoIfDoesntExist(object.Key, albumId);
    }
  });

  if (data.isTruncated) {
    params.ContinuationToken = data.NextContinuationToken;
    insertKeysIntoAlbum(params);
  } else if (params.ContinuationToken) {
    delete params.ContinuationToken;
  }
}

function insertOrFindAlbum(albumName) {
  const album = Albums.findOne({
    name: albumName
  });

  if (album) {
    return album._id;
  }

  return Albums.insert({
    name: albumName
  });
}

function updateFromAws() {
  return Promise.asyncApply(() => {
    Promise.await(lister.ls(`/${mainFolder}`).then(data => {
      _.forEach(data.folders, function (folder) {
        params.Prefix = folder;

        const folderName = _.trim(_.replace(folder, mainFolder, ''), '/');

        const albumId = insertOrFindAlbum(folderName);
        insertKeysIntoAlbum(params, albumId);
        const album = Albums.findOne(albumId);

        if (!album.featuredImageKey) {
          Albums.update({
            _id: albumId
          }, {
            $set: {
              featuredImageKey: Photos.findOne({
                albumId
              }).key
            }
          });
        }
      });
    }));
  });
}

if (Meteor.isServer) {
  Meteor.methods({
    'aws.update'() {
      updateFromAws();
    }

  });
}
//////////////////////////////////////////////////////////////////////////////////////////////

},"photos.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// imports/api/photos.js                                                                    //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
module.export({
  Photos: () => Photos
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let publishPagination;
module.watch(require("meteor/kurounin:pagination"), {
  publishPagination(v) {
    publishPagination = v;
  }

}, 2);
const Photos = new Mongo.Collection('photos');
module.exportDefault(Photos);

if (Meteor.isServer) {
  publishPagination(Photos);
}
//////////////////////////////////////////////////////////////////////////////////////////////

}},"startup":{"accounts-config.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// imports/startup/accounts-config.js                                                       //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

if (Meteor.isServer) {
  Accounts.config({
    forbidClientAccountCreation: true
  });

  if (Meteor.users.find().count() === 0) {
    Accounts.createUser({
      username: 'admin',
      password: 'password'
    });
  }
}
//////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// server/main.js                                                                           //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
module.watch(require("../imports/api/aws.js"));
module.watch(require("../imports/api/albums.js"));
module.watch(require("../imports/api/photos.js"));
module.watch(require("../imports/startup/accounts-config.js"));
//////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWxidW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9hd3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Bob3Rvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2FjY291bnRzLWNvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiQWxidW1zIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1vbmdvIiwicHVibGlzaFBhZ2luYXRpb24iLCJDb2xsZWN0aW9uIiwiZXhwb3J0RGVmYXVsdCIsImlzU2VydmVyIiwiQVdTIiwiczNscyIsImRlZmF1bHQiLCJfIiwiZXhpZlRvb2xCaW4iLCJFeGlmIiwicnAiLCJQaG90b3MiLCJzZXR0aW5ncyIsIkVycm9yIiwiYnVja2V0TmFtZSIsInMzQnVja2V0TmFtZSIsIm1haW5Gb2xkZXIiLCJzM0J1Y2tldE1haW5Gb2xkZXIiLCJjb25maWciLCJ1cGRhdGUiLCJhY2Nlc3NLZXlJZCIsInNlY3JldEFjY2Vzc0tleSIsInMzIiwiUzMiLCJsaXN0ZXIiLCJidWNrZXQiLCJwYXJhbXMiLCJCdWNrZXQiLCJnZXRFWElGRnJvbUJpbmFyeSIsImRhdGEiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImJpbmFyeSIsImFyZ3MiLCJlcnJvciIsIm1ldGFkYXRhIiwia2V5c1RvRXhjbHVkZSIsIm9taXQiLCJnZXRFeGlmRGF0YUFzeW5jIiwicGhvdG8iLCJ1cmwiLCJlbmNvZGVVUkkiLCJwdWJsaWMiLCJwaG90b3NCYXNlVXJsIiwia2V5IiwicmVzcG9uc2UiLCJ1cmkiLCJlbmNvZGluZyIsInRhZ3MiLCJlcnIiLCJpbnNlcnRQaG90b0lmRG9lc250RXhpc3QiLCJhbGJ1bUlkIiwicGhvdG9QYXJhbXMiLCJmaW5kT25lIiwibmV3SWQiLCJpbnNlcnQiLCJleGlmRGF0YSIsIl9pZCIsIiRzZXQiLCJpbnNlcnRLZXlzSW50b0FsYnVtIiwiczNwYXJhbXMiLCJsaXN0T2JqZWN0c1YyU3luYyIsImZvckVhY2giLCJDb250ZW50cyIsIm9iamVjdCIsInMzTG93UXVhbGl0eUZvbGRlck5hbWUiLCJpbmNsdWRlcyIsIktleSIsImlzVHJ1bmNhdGVkIiwiQ29udGludWF0aW9uVG9rZW4iLCJOZXh0Q29udGludWF0aW9uVG9rZW4iLCJpbnNlcnRPckZpbmRBbGJ1bSIsImFsYnVtTmFtZSIsImFsYnVtIiwibmFtZSIsInVwZGF0ZUZyb21Bd3MiLCJscyIsInRoZW4iLCJmb2xkZXJzIiwiZm9sZGVyIiwiUHJlZml4IiwiZm9sZGVyTmFtZSIsInRyaW0iLCJyZXBsYWNlIiwiZmVhdHVyZWRJbWFnZUtleSIsIm1ldGhvZHMiLCJBY2NvdW50cyIsImZvcmJpZENsaWVudEFjY291bnRDcmVhdGlvbiIsInVzZXJzIiwiZmluZCIsImNvdW50IiwiY3JlYXRlVXNlciIsInVzZXJuYW1lIiwicGFzc3dvcmQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE9BQU9DLE1BQVAsQ0FBYztBQUFDQyxVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJQyxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLGlCQUFKO0FBQXNCUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDRyxvQkFBa0JGLENBQWxCLEVBQW9CO0FBQUNFLHdCQUFrQkYsQ0FBbEI7QUFBb0I7O0FBQTFDLENBQW5ELEVBQStGLENBQS9GO0FBSWxNLE1BQU1KLFNBQVMsSUFBSUssTUFBTUUsVUFBVixDQUFxQixRQUFyQixDQUFmO0FBSlBULE9BQU9VLGFBQVAsQ0FLZVIsTUFMZjs7QUFPQSxJQUFJQyxPQUFPUSxRQUFYLEVBQXFCO0FBQ25CSCxvQkFBa0JOLE1BQWxCO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUNURCxJQUFJQyxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSU0sR0FBSjtBQUFRWixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDTyxNQUFJTixDQUFKLEVBQU07QUFBQ00sVUFBSU4sQ0FBSjtBQUFNOztBQUFkLENBQW5ELEVBQW1FLENBQW5FO0FBQXNFLElBQUlPLElBQUo7QUFBU2IsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDUyxVQUFRUixDQUFSLEVBQVU7QUFBQ08sV0FBS1AsQ0FBTDtBQUFPOztBQUFuQixDQUE5QixFQUFtRCxDQUFuRDs7QUFBc0QsSUFBSVMsQ0FBSjs7QUFBTWYsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDUyxVQUFRUixDQUFSLEVBQVU7QUFBQ1MsUUFBRVQsQ0FBRjtBQUFJOztBQUFoQixDQUEvQixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJVSxXQUFKO0FBQWdCaEIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDUyxVQUFRUixDQUFSLEVBQVU7QUFBQ1Usa0JBQVlWLENBQVo7QUFBYzs7QUFBMUIsQ0FBdEMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSVcsSUFBSjtBQUFTakIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGlCQUFSLENBQWIsRUFBd0M7QUFBQ1MsVUFBUVIsQ0FBUixFQUFVO0FBQUNXLFdBQUtYLENBQUw7QUFBTzs7QUFBbkIsQ0FBeEMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSVksRUFBSjtBQUFPbEIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGlCQUFSLENBQWIsRUFBd0M7QUFBQ1MsVUFBUVIsQ0FBUixFQUFVO0FBQUNZLFNBQUdaLENBQUg7QUFBSzs7QUFBakIsQ0FBeEMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSUosTUFBSjtBQUFXRixPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXBDLEVBQTBELENBQTFEO0FBQTZELElBQUlhLE1BQUo7QUFBV25CLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ2MsU0FBT2IsQ0FBUCxFQUFTO0FBQUNhLGFBQU9iLENBQVA7QUFBUzs7QUFBcEIsQ0FBcEMsRUFBMEQsQ0FBMUQ7O0FBY3ZrQixJQUFJLENBQUNILE9BQU9pQixRQUFQLENBQWdCUixHQUFyQixFQUEwQjtBQUN4QixRQUFPLElBQUlULE9BQU9rQixLQUFYLENBQWlCLGdDQUFqQixDQUFQO0FBQ0Q7O0FBRUQsTUFBTUMsYUFBYW5CLE9BQU9pQixRQUFQLENBQWdCUixHQUFoQixDQUFvQlcsWUFBdkM7QUFDQSxNQUFNQyxhQUFhckIsT0FBT2lCLFFBQVAsQ0FBZ0JSLEdBQWhCLENBQW9CYSxrQkFBdkM7QUFFQWIsSUFBSWMsTUFBSixDQUFXQyxNQUFYLENBQWtCO0FBQ2hCQyxlQUFhekIsT0FBT2lCLFFBQVAsQ0FBZ0JSLEdBQWhCLENBQW9CZ0IsV0FEakI7QUFFaEJDLG1CQUFpQjFCLE9BQU9pQixRQUFQLENBQWdCUixHQUFoQixDQUFvQmlCO0FBRnJCLENBQWxCO0FBS0EsTUFBTUMsS0FBSyxJQUFJbEIsSUFBSW1CLEVBQVIsRUFBWDtBQUNBLE1BQU1DLFNBQVNuQixLQUFLO0FBQUVvQixVQUFRWCxVQUFWO0FBQXNCUTtBQUF0QixDQUFMLENBQWY7QUFFQSxNQUFNSSxTQUFTO0FBQ2JDLFVBQVFiO0FBREssQ0FBZjs7QUFJQSxTQUFTYyxpQkFBVCxDQUEyQkMsSUFBM0IsRUFBaUM7QUFDL0IsU0FBTyxJQUFJQyxPQUFKLENBQVksVUFBU0MsT0FBVCxFQUFrQkMsTUFBbEIsRUFBMEI7QUFDM0N2QixTQUFLb0IsSUFBTCxFQUFXO0FBQUVJLGNBQVF6QixXQUFWO0FBQXVCMEIsWUFBTSxDQUFDLE9BQUQsRUFBVSxJQUFWLEVBQWdCLFdBQWhCLEVBQTZCLFdBQTdCO0FBQTdCLEtBQVgsRUFBcUYsQ0FBQ0MsS0FBRCxFQUFRQyxRQUFSLEtBQXFCO0FBQ3hHLFVBQUlELEtBQUosRUFBVztBQUNUSCxlQUFPRyxLQUFQO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsY0FBTUUsZ0JBQWdCLENBQ3BCLGlCQURvQixFQUVwQixpQkFGb0IsRUFHcEIsZ0JBSG9CLENBQXRCO0FBS0FOLGdCQUFReEIsRUFBRStCLElBQUYsQ0FBT0YsUUFBUCxFQUFpQkMsYUFBakIsQ0FBUjtBQUNEO0FBQ0YsS0FYRDtBQVlELEdBYk0sQ0FBUDtBQWNEOztBQUVELFNBQWVFLGdCQUFmLENBQWdDQyxLQUFoQztBQUFBLGtDQUF1QztBQUNyQyxRQUFJO0FBQ0YsWUFBTUMsTUFBTUMsVUFBVyxVQUFTL0MsT0FBT2lCLFFBQVAsQ0FBZ0IrQixNQUFoQixDQUF1QkMsYUFBYyxJQUFHSixNQUFNSyxHQUFJLEVBQXRFLENBQVo7QUFDQSxZQUFNQyx5QkFBaUJwQyxHQUFHO0FBQ3hCcUMsYUFBS04sR0FEbUI7QUFFeEJPLGtCQUFVO0FBRmMsT0FBSCxDQUFqQixDQUFOO0FBSUEsWUFBTUMscUJBQWFyQixrQkFBa0JrQixRQUFsQixDQUFiLENBQU47QUFDQSxhQUFPRyxJQUFQO0FBQ0QsS0FSRCxDQVFFLE9BQU9DLEdBQVAsRUFBWTtBQUNaLGFBQU8sSUFBUDtBQUNEO0FBQ0YsR0FaRDtBQUFBOztBQWNBLFNBQWVDLHdCQUFmLENBQXdDTixHQUF4QyxFQUE2Q08sT0FBN0M7QUFBQSxrQ0FBc0Q7QUFDcEQsVUFBTUMsY0FBYztBQUNsQlIsU0FEa0I7QUFFbEJPO0FBRmtCLEtBQXBCO0FBSUEsUUFBSVosUUFBUTdCLE9BQU8yQyxPQUFQLENBQWVELFdBQWYsQ0FBWjs7QUFDQSxRQUFJLENBQUNiLEtBQUwsRUFBWTtBQUNWLFlBQU1lLFFBQVE1QyxPQUFPNkMsTUFBUCxDQUFjSCxXQUFkLENBQWQ7QUFDQWIsY0FBUTdCLE9BQU8yQyxPQUFQLENBQWVDLEtBQWYsQ0FBUjtBQUNEOztBQUNELFFBQUksQ0FBQ2YsTUFBTUosUUFBWCxFQUFxQjtBQUNuQixZQUFNcUIseUJBQWlCbEIsaUJBQWlCQyxLQUFqQixDQUFqQixDQUFOO0FBQ0E3QixhQUFPUSxNQUFQLENBQWNxQixNQUFNa0IsR0FBcEIsRUFBeUI7QUFDdkJDLGNBQU07QUFDSnZCLG9CQUFVcUI7QUFETjtBQURpQixPQUF6QjtBQUtEO0FBQ0YsR0FsQkQ7QUFBQTs7QUFvQkEsU0FBU0csbUJBQVQsQ0FBNkJDLFFBQTdCLEVBQXVDVCxPQUF2QyxFQUFnRDtBQUM5QyxRQUFNdkIsT0FBT1AsR0FBR3dDLGlCQUFILENBQXFCRCxRQUFyQixDQUFiOztBQUNBdEQsSUFBRXdELE9BQUYsQ0FBVWxDLEtBQUttQyxRQUFmLEVBQXlCLFVBQVNDLE1BQVQsRUFBaUI7QUFDeEMsUUFBSXRFLE9BQU9pQixRQUFQLENBQWdCK0IsTUFBaEIsQ0FBdUJ2QyxHQUF2QixDQUEyQjhELHNCQUEvQixFQUF1RDtBQUNyRCxVQUFJM0QsRUFBRTRELFFBQUYsQ0FBV0YsT0FBT0csR0FBbEIsRUFBdUJ6RSxPQUFPaUIsUUFBUCxDQUFnQitCLE1BQWhCLENBQXVCdkMsR0FBdkIsQ0FBMkI4RCxzQkFBbEQsQ0FBSixFQUErRTtBQUM3RWYsaUNBQXlCYyxPQUFPRyxHQUFoQyxFQUFxQ2hCLE9BQXJDO0FBQ0Q7QUFDRixLQUpELE1BSU87QUFDTEQsK0JBQXlCYyxPQUFPRyxHQUFoQyxFQUFxQ2hCLE9BQXJDO0FBQ0Q7QUFDRixHQVJEOztBQVVBLE1BQUl2QixLQUFLd0MsV0FBVCxFQUFzQjtBQUNwQjNDLFdBQU80QyxpQkFBUCxHQUEyQnpDLEtBQUswQyxxQkFBaEM7QUFDQVgsd0JBQW9CbEMsTUFBcEI7QUFDRCxHQUhELE1BR08sSUFBSUEsT0FBTzRDLGlCQUFYLEVBQThCO0FBQ25DLFdBQU81QyxPQUFPNEMsaUJBQWQ7QUFDRDtBQUNGOztBQUVELFNBQVNFLGlCQUFULENBQTJCQyxTQUEzQixFQUFzQztBQUNwQyxRQUFNQyxRQUFRaEYsT0FBTzRELE9BQVAsQ0FBZTtBQUFFcUIsVUFBTUY7QUFBUixHQUFmLENBQWQ7O0FBQ0EsTUFBSUMsS0FBSixFQUFXO0FBQ1QsV0FBT0EsTUFBTWhCLEdBQWI7QUFDRDs7QUFDRCxTQUFPaEUsT0FBTzhELE1BQVAsQ0FBYztBQUFFbUIsVUFBTUY7QUFBUixHQUFkLENBQVA7QUFDRDs7QUFFRCxTQUFlRyxhQUFmO0FBQUEsa0NBQStCO0FBQzdCLGtCQUFNcEQsT0FBT3FELEVBQVAsQ0FBVyxJQUFHN0QsVUFBVyxFQUF6QixFQUE0QjhELElBQTVCLENBQWtDakQsSUFBRCxJQUFVO0FBQy9DdEIsUUFBRXdELE9BQUYsQ0FBVWxDLEtBQUtrRCxPQUFmLEVBQXdCLFVBQVNDLE1BQVQsRUFBaUI7QUFDdkN0RCxlQUFPdUQsTUFBUCxHQUFnQkQsTUFBaEI7O0FBQ0EsY0FBTUUsYUFBYTNFLEVBQUU0RSxJQUFGLENBQU81RSxFQUFFNkUsT0FBRixDQUFVSixNQUFWLEVBQWtCaEUsVUFBbEIsRUFBOEIsRUFBOUIsQ0FBUCxFQUEwQyxHQUExQyxDQUFuQjs7QUFDQSxjQUFNb0MsVUFBVW9CLGtCQUFrQlUsVUFBbEIsQ0FBaEI7QUFDQXRCLDRCQUFvQmxDLE1BQXBCLEVBQTRCMEIsT0FBNUI7QUFDQSxjQUFNc0IsUUFBUWhGLE9BQU80RCxPQUFQLENBQWVGLE9BQWYsQ0FBZDs7QUFDQSxZQUFJLENBQUNzQixNQUFNVyxnQkFBWCxFQUE2QjtBQUMzQjNGLGlCQUFPeUIsTUFBUCxDQUFjO0FBQUV1QyxpQkFBS047QUFBUCxXQUFkLEVBQWdDO0FBQzlCTyxrQkFBTTtBQUNKMEIsZ0NBQWtCMUUsT0FBTzJDLE9BQVAsQ0FBZTtBQUFFRjtBQUFGLGVBQWYsRUFBNEJQO0FBRDFDO0FBRHdCLFdBQWhDO0FBS0Q7QUFDRixPQWJEO0FBY0QsS0FmSyxDQUFOO0FBZ0JELEdBakJEO0FBQUE7O0FBb0JBLElBQUlsRCxPQUFPUSxRQUFYLEVBQXFCO0FBQ25CUixTQUFPMkYsT0FBUCxDQUFlO0FBQ2IsbUJBQWU7QUFDYlY7QUFDRDs7QUFIWSxHQUFmO0FBS0QsQzs7Ozs7Ozs7Ozs7QUMxSURwRixPQUFPQyxNQUFQLENBQWM7QUFBQ2tCLFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUloQixNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLGlCQUFKO0FBQXNCUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDRyxvQkFBa0JGLENBQWxCLEVBQW9CO0FBQUNFLHdCQUFrQkYsQ0FBbEI7QUFBb0I7O0FBQTFDLENBQW5ELEVBQStGLENBQS9GO0FBS2xNLE1BQU1hLFNBQVMsSUFBSVosTUFBTUUsVUFBVixDQUFxQixRQUFyQixDQUFmO0FBTFBULE9BQU9VLGFBQVAsQ0FNZVMsTUFOZjs7QUFRQSxJQUFJaEIsT0FBT1EsUUFBWCxFQUFxQjtBQUNuQkgsb0JBQWtCVyxNQUFsQjtBQUNELEM7Ozs7Ozs7Ozs7O0FDVkQsSUFBSTRFLFFBQUo7QUFBYS9GLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUMwRixXQUFTekYsQ0FBVCxFQUFXO0FBQUN5RixlQUFTekYsQ0FBVDtBQUFXOztBQUF4QixDQUE3QyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJSCxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBR2xHLElBQUlILE9BQU9RLFFBQVgsRUFBcUI7QUFDbkJvRixXQUFTckUsTUFBVCxDQUFnQjtBQUNkc0UsaUNBQTZCO0FBRGYsR0FBaEI7O0FBSUEsTUFBSTdGLE9BQU84RixLQUFQLENBQWFDLElBQWIsR0FBb0JDLEtBQXBCLE9BQWdDLENBQXBDLEVBQXVDO0FBQ3JDSixhQUFTSyxVQUFULENBQW9CO0FBQ2xCQyxnQkFBVSxPQURRO0FBRWxCQyxnQkFBVTtBQUZRLEtBQXBCO0FBSUQ7QUFDRixDOzs7Ozs7Ozs7OztBQ2REdEcsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWI7QUFBK0NMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiO0FBQWtETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYjtBQUFrREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVDQUFSLENBQWIsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBwdWJsaXNoUGFnaW5hdGlvbiB9IGZyb20gJ21ldGVvci9rdXJvdW5pbjpwYWdpbmF0aW9uJztcblxuZXhwb3J0IGNvbnN0IEFsYnVtcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhbGJ1bXMnKTtcbmV4cG9ydCBkZWZhdWx0IEFsYnVtcztcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBwdWJsaXNoUGFnaW5hdGlvbihBbGJ1bXMpO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBV1MgfSBmcm9tICdtZXRlb3IvcGVlcmxpYnJhcnk6YXdzLXNkayc7XG5cbmltcG9ydCBzM2xzIGZyb20gJ3MzLWxzJztcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5pbXBvcnQgZXhpZlRvb2xCaW4gZnJvbSAnZGlzdC1leGlmdG9vbCc7XG5pbXBvcnQgRXhpZiBmcm9tICdzaW1wbGUtZXhpZnRvb2wnO1xuaW1wb3J0IHJwIGZyb20gJ3JlcXVlc3QtcHJvbWlzZSc7XG5cbmltcG9ydCB7IEFsYnVtcyB9IGZyb20gJy4vYWxidW1zLmpzJztcblxuaW1wb3J0IHsgUGhvdG9zIH0gZnJvbSAnLi9waG90b3MuanMnO1xuXG5cbmlmICghTWV0ZW9yLnNldHRpbmdzLkFXUykge1xuICB0aHJvdyAobmV3IE1ldGVvci5FcnJvcignQVdTIFNldHRpbmdzIG11c3QgYmUgc3BlY2lmaWVkJykpO1xufVxuXG5jb25zdCBidWNrZXROYW1lID0gTWV0ZW9yLnNldHRpbmdzLkFXUy5zM0J1Y2tldE5hbWU7XG5jb25zdCBtYWluRm9sZGVyID0gTWV0ZW9yLnNldHRpbmdzLkFXUy5zM0J1Y2tldE1haW5Gb2xkZXI7XG5cbkFXUy5jb25maWcudXBkYXRlKHtcbiAgYWNjZXNzS2V5SWQ6IE1ldGVvci5zZXR0aW5ncy5BV1MuYWNjZXNzS2V5SWQsXG4gIHNlY3JldEFjY2Vzc0tleTogTWV0ZW9yLnNldHRpbmdzLkFXUy5zZWNyZXRBY2Nlc3NLZXksXG59KTtcblxuY29uc3QgczMgPSBuZXcgQVdTLlMzKCk7XG5jb25zdCBsaXN0ZXIgPSBzM2xzKHsgYnVja2V0OiBidWNrZXROYW1lLCBzMyB9KTtcblxuY29uc3QgcGFyYW1zID0ge1xuICBCdWNrZXQ6IGJ1Y2tldE5hbWUsXG59O1xuXG5mdW5jdGlvbiBnZXRFWElGRnJvbUJpbmFyeShkYXRhKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbihyZXNvbHZlLCByZWplY3QpIHtcbiAgICBFeGlmKGRhdGEsIHsgYmluYXJ5OiBleGlmVG9vbEJpbiwgYXJnczogWyctanNvbicsICctcycsICctaXB0YzphbGwnLCAnLWV4aWY6YWxsJ10gfSwgKGVycm9yLCBtZXRhZGF0YSkgPT4ge1xuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBrZXlzVG9FeGNsdWRlID0gW1xuICAgICAgICAgICdUaHVtYm5haWxPZmZzZXQnLFxuICAgICAgICAgICdUaHVtYm5haWxMZW5ndGgnLFxuICAgICAgICAgICdUaHVtYm5haWxJbWFnZScsXG4gICAgICAgIF07XG4gICAgICAgIHJlc29sdmUoXy5vbWl0KG1ldGFkYXRhLCBrZXlzVG9FeGNsdWRlKSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBnZXRFeGlmRGF0YUFzeW5jKHBob3RvKSB7XG4gIHRyeSB7XG4gICAgY29uc3QgdXJsID0gZW5jb2RlVVJJKGBodHRwOi8vJHtNZXRlb3Iuc2V0dGluZ3MucHVibGljLnBob3Rvc0Jhc2VVcmx9LyR7cGhvdG8ua2V5fWApO1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcnAoe1xuICAgICAgdXJpOiB1cmwsXG4gICAgICBlbmNvZGluZzogbnVsbCxcbiAgICB9KTtcbiAgICBjb25zdCB0YWdzID0gYXdhaXQgZ2V0RVhJRkZyb21CaW5hcnkocmVzcG9uc2UpO1xuICAgIHJldHVybiB0YWdzO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBpbnNlcnRQaG90b0lmRG9lc250RXhpc3Qoa2V5LCBhbGJ1bUlkKSB7XG4gIGNvbnN0IHBob3RvUGFyYW1zID0ge1xuICAgIGtleSxcbiAgICBhbGJ1bUlkLFxuICB9O1xuICBsZXQgcGhvdG8gPSBQaG90b3MuZmluZE9uZShwaG90b1BhcmFtcyk7XG4gIGlmICghcGhvdG8pIHtcbiAgICBjb25zdCBuZXdJZCA9IFBob3Rvcy5pbnNlcnQocGhvdG9QYXJhbXMpO1xuICAgIHBob3RvID0gUGhvdG9zLmZpbmRPbmUobmV3SWQpO1xuICB9XG4gIGlmICghcGhvdG8ubWV0YWRhdGEpIHtcbiAgICBjb25zdCBleGlmRGF0YSA9IGF3YWl0IGdldEV4aWZEYXRhQXN5bmMocGhvdG8pO1xuICAgIFBob3Rvcy51cGRhdGUocGhvdG8uX2lkLCB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIG1ldGFkYXRhOiBleGlmRGF0YSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gaW5zZXJ0S2V5c0ludG9BbGJ1bShzM3BhcmFtcywgYWxidW1JZCkge1xuICBjb25zdCBkYXRhID0gczMubGlzdE9iamVjdHNWMlN5bmMoczNwYXJhbXMpO1xuICBfLmZvckVhY2goZGF0YS5Db250ZW50cywgZnVuY3Rpb24ob2JqZWN0KSB7XG4gICAgaWYgKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuQVdTLnMzTG93UXVhbGl0eUZvbGRlck5hbWUpIHtcbiAgICAgIGlmIChfLmluY2x1ZGVzKG9iamVjdC5LZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuQVdTLnMzTG93UXVhbGl0eUZvbGRlck5hbWUpKSB7XG4gICAgICAgIGluc2VydFBob3RvSWZEb2VzbnRFeGlzdChvYmplY3QuS2V5LCBhbGJ1bUlkKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaW5zZXJ0UGhvdG9JZkRvZXNudEV4aXN0KG9iamVjdC5LZXksIGFsYnVtSWQpO1xuICAgIH1cbiAgfSk7XG5cbiAgaWYgKGRhdGEuaXNUcnVuY2F0ZWQpIHtcbiAgICBwYXJhbXMuQ29udGludWF0aW9uVG9rZW4gPSBkYXRhLk5leHRDb250aW51YXRpb25Ub2tlbjtcbiAgICBpbnNlcnRLZXlzSW50b0FsYnVtKHBhcmFtcyk7XG4gIH0gZWxzZSBpZiAocGFyYW1zLkNvbnRpbnVhdGlvblRva2VuKSB7XG4gICAgZGVsZXRlIHBhcmFtcy5Db250aW51YXRpb25Ub2tlbjtcbiAgfVxufVxuXG5mdW5jdGlvbiBpbnNlcnRPckZpbmRBbGJ1bShhbGJ1bU5hbWUpIHtcbiAgY29uc3QgYWxidW0gPSBBbGJ1bXMuZmluZE9uZSh7IG5hbWU6IGFsYnVtTmFtZSB9KTtcbiAgaWYgKGFsYnVtKSB7XG4gICAgcmV0dXJuIGFsYnVtLl9pZDtcbiAgfVxuICByZXR1cm4gQWxidW1zLmluc2VydCh7IG5hbWU6IGFsYnVtTmFtZSB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gdXBkYXRlRnJvbUF3cygpIHtcbiAgYXdhaXQgbGlzdGVyLmxzKGAvJHttYWluRm9sZGVyfWApLnRoZW4oKGRhdGEpID0+IHtcbiAgICBfLmZvckVhY2goZGF0YS5mb2xkZXJzLCBmdW5jdGlvbihmb2xkZXIpIHtcbiAgICAgIHBhcmFtcy5QcmVmaXggPSBmb2xkZXI7XG4gICAgICBjb25zdCBmb2xkZXJOYW1lID0gXy50cmltKF8ucmVwbGFjZShmb2xkZXIsIG1haW5Gb2xkZXIsICcnKSwgJy8nKTtcbiAgICAgIGNvbnN0IGFsYnVtSWQgPSBpbnNlcnRPckZpbmRBbGJ1bShmb2xkZXJOYW1lKTtcbiAgICAgIGluc2VydEtleXNJbnRvQWxidW0ocGFyYW1zLCBhbGJ1bUlkKTtcbiAgICAgIGNvbnN0IGFsYnVtID0gQWxidW1zLmZpbmRPbmUoYWxidW1JZCk7XG4gICAgICBpZiAoIWFsYnVtLmZlYXR1cmVkSW1hZ2VLZXkpIHtcbiAgICAgICAgQWxidW1zLnVwZGF0ZSh7IF9pZDogYWxidW1JZCB9LCB7XG4gICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgZmVhdHVyZWRJbWFnZUtleTogUGhvdG9zLmZpbmRPbmUoeyBhbGJ1bUlkIH0pLmtleSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59XG5cblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgJ2F3cy51cGRhdGUnKCkge1xuICAgICAgdXBkYXRlRnJvbUF3cygpO1xuICAgIH0sXG4gIH0pO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBwdWJsaXNoUGFnaW5hdGlvbiB9IGZyb20gJ21ldGVvci9rdXJvdW5pbjpwYWdpbmF0aW9uJztcblxuXG5leHBvcnQgY29uc3QgUGhvdG9zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3Bob3RvcycpO1xuZXhwb3J0IGRlZmF1bHQgUGhvdG9zO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIHB1Ymxpc2hQYWdpbmF0aW9uKFBob3Rvcyk7XG59XG4iLCJpbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIEFjY291bnRzLmNvbmZpZyh7XG4gICAgZm9yYmlkQ2xpZW50QWNjb3VudENyZWF0aW9uOiB0cnVlLFxuICB9KTtcblxuICBpZiAoTWV0ZW9yLnVzZXJzLmZpbmQoKS5jb3VudCgpID09PSAwKSB7XG4gICAgQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICB1c2VybmFtZTogJ2FkbWluJyxcbiAgICAgIHBhc3N3b3JkOiAncGFzc3dvcmQnLFxuICAgIH0pO1xuICB9XG59XG4iLCJpbXBvcnQgJy4uL2ltcG9ydHMvYXBpL2F3cy5qcyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL2FsYnVtcy5qcyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL3Bob3Rvcy5qcyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvc3RhcnR1cC9hY2NvdW50cy1jb25maWcuanMnO1xuIl19
