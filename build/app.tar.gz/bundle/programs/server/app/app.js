var require = meteorInstall({"imports":{"api":{"albums.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/albums.js                                                                           //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({
  Albums: () => Albums
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let publishPagination;
module.watch(require("meteor/kurounin:pagination"), {
  publishPagination(v) {
    publishPagination = v;
  }

}, 2);
const Albums = new Mongo.Collection('albums');
module.exportDefault(Albums);

if (Meteor.isServer) {
  publishPagination(Albums);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"aws.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/aws.js                                                                              //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let AWS;
module.watch(require("meteor/peerlibrary:aws-sdk"), {
  AWS(v) {
    AWS = v;
  }

}, 1);
let s3ls;
module.watch(require("s3-ls"), {
  default(v) {
    s3ls = v;
  }

}, 2);

let _;

module.watch(require("lodash"), {
  default(v) {
    _ = v;
  }

}, 3);
let exifToolBin;
module.watch(require("dist-exiftool"), {
  default(v) {
    exifToolBin = v;
  }

}, 4);
let Exif;
module.watch(require("simple-exiftool"), {
  default(v) {
    Exif = v;
  }

}, 5);
let rp;
module.watch(require("request-promise"), {
  default(v) {
    rp = v;
  }

}, 6);
let Albums;
module.watch(require("./albums.js"), {
  Albums(v) {
    Albums = v;
  }

}, 7);
let Photos;
module.watch(require("./photos.js"), {
  Photos(v) {
    Photos = v;
  }

}, 8);

if (!Meteor.settings.AWS) {
  throw new Meteor.Error('AWS Settings must be specified');
}

const bucketName = Meteor.settings.AWS.s3BucketName;
const mainFolder = Meteor.settings.AWS.s3BucketMainFolder;
AWS.config.update({
  accessKeyId: Meteor.settings.AWS.accessKeyId,
  secretAccessKey: Meteor.settings.AWS.secretAccessKey
});
const s3 = new AWS.S3();
const lister = s3ls({
  bucket: bucketName,
  s3
});
const params = {
  Bucket: bucketName
};

function getEXIFFromBinary(data) {
  return new Promise(function (resolve, reject) {
    const exifToolArgs = ['-json', '-s', '-iptc:all', '-exif:all', '-location:all', '-xmp:label'];
    Exif(data, {
      binary: exifToolBin,
      args: exifToolArgs
    }, (error, metadata) => {
      if (error) {
        reject(error);
      } else {
        const keysToExclude = ['ThumbnailOffset', 'ThumbnailLength', 'ThumbnailImage'];
        resolve(_.omit(metadata, keysToExclude));
      }
    });
  });
}

function getExifDataAsync(photo) {
  return Promise.asyncApply(() => {
    try {
      const url = encodeURI(`http://${Meteor.settings.public.photosBaseUrl}/${photo.key}`);
      const response = Promise.await(rp({
        uri: url,
        encoding: null
      }));
      const tags = Promise.await(getEXIFFromBinary(response));
      return tags;
    } catch (err) {
      return null;
    }
  });
}

function insertPhotoIfDoesntExist(key, albumId) {
  return Promise.asyncApply(() => {
    const photoParams = {
      key,
      albumId
    };
    let photo = Photos.findOne(photoParams);

    if (!photo) {
      const newId = Photos.insert(photoParams);
      photo = Photos.findOne(newId);
    }

    if (!photo.metadata) {
      const exifData = Promise.await(getExifDataAsync(photo));
      Photos.update(photo._id, {
        $set: {
          metadata: exifData
        }
      });
    }
  });
}

function insertKeysIntoAlbum(s3params, albumId) {
  const data = s3.listObjectsV2Sync(s3params);

  _.forEach(data.Contents, function (object) {
    if (Meteor.settings.public.AWS.s3LowQualityFolderName) {
      if (_.includes(object.Key, Meteor.settings.public.AWS.s3LowQualityFolderName)) {
        insertPhotoIfDoesntExist(object.Key, albumId);
      }
    } else {
      insertPhotoIfDoesntExist(object.Key, albumId);
    }
  });

  if (data.isTruncated) {
    params.ContinuationToken = data.NextContinuationToken;
    insertKeysIntoAlbum(params);
  } else if (params.ContinuationToken) {
    delete params.ContinuationToken;
  }
}

function insertOrFindAlbum(albumName) {
  const album = Albums.findOne({
    name: albumName
  });

  if (album) {
    return album._id;
  }

  return Albums.insert({
    name: albumName
  });
}

function updateFromAws() {
  return Promise.asyncApply(() => {
    Promise.await(lister.ls(`/${mainFolder}`).then(data => {
      _.forEach(data.folders, function (folder) {
        params.Prefix = folder;

        const folderName = _.trim(_.replace(folder, mainFolder, ''), '/');

        const albumId = insertOrFindAlbum(folderName);
        insertKeysIntoAlbum(params, albumId);
        const album = Albums.findOne(albumId);

        if (!album.featuredImageKey) {
          Albums.update({
            _id: albumId
          }, {
            $set: {
              featuredImageKey: Photos.findOne({
                albumId
              }).key
            }
          });
        }
      });
    }));
  });
}

if (Meteor.isServer) {
  Meteor.methods({
    'aws.update'() {
      return Promise.asyncApply(() => {
        Promise.await(updateFromAws());
      });
    }

  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"photos.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/photos.js                                                                           //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({
  Photos: () => Photos
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let publishPagination;
module.watch(require("meteor/kurounin:pagination"), {
  publishPagination(v) {
    publishPagination = v;
  }

}, 2);
const Photos = new Mongo.Collection('photos');
module.exportDefault(Photos);

if (Meteor.isServer) {
  publishPagination(Photos);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup":{"accounts-config.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/startup/accounts-config.js                                                              //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

if (Meteor.isServer) {
  Accounts.config({
    forbidClientAccountCreation: true
  });

  if (Meteor.users.find().count() === 0) {
    Accounts.createUser({
      username: 'admin',
      password: 'password'
    });
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/main.js                                                                                  //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.watch(require("../imports/api/aws.js"));
module.watch(require("../imports/api/albums.js"));
module.watch(require("../imports/api/photos.js"));
module.watch(require("../imports/startup/accounts-config.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWxidW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9hd3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Bob3Rvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2FjY291bnRzLWNvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiQWxidW1zIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1vbmdvIiwicHVibGlzaFBhZ2luYXRpb24iLCJDb2xsZWN0aW9uIiwiZXhwb3J0RGVmYXVsdCIsImlzU2VydmVyIiwiQVdTIiwiczNscyIsImRlZmF1bHQiLCJfIiwiZXhpZlRvb2xCaW4iLCJFeGlmIiwicnAiLCJQaG90b3MiLCJzZXR0aW5ncyIsIkVycm9yIiwiYnVja2V0TmFtZSIsInMzQnVja2V0TmFtZSIsIm1haW5Gb2xkZXIiLCJzM0J1Y2tldE1haW5Gb2xkZXIiLCJjb25maWciLCJ1cGRhdGUiLCJhY2Nlc3NLZXlJZCIsInNlY3JldEFjY2Vzc0tleSIsInMzIiwiUzMiLCJsaXN0ZXIiLCJidWNrZXQiLCJwYXJhbXMiLCJCdWNrZXQiLCJnZXRFWElGRnJvbUJpbmFyeSIsImRhdGEiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImV4aWZUb29sQXJncyIsImJpbmFyeSIsImFyZ3MiLCJlcnJvciIsIm1ldGFkYXRhIiwia2V5c1RvRXhjbHVkZSIsIm9taXQiLCJnZXRFeGlmRGF0YUFzeW5jIiwicGhvdG8iLCJ1cmwiLCJlbmNvZGVVUkkiLCJwdWJsaWMiLCJwaG90b3NCYXNlVXJsIiwia2V5IiwicmVzcG9uc2UiLCJ1cmkiLCJlbmNvZGluZyIsInRhZ3MiLCJlcnIiLCJpbnNlcnRQaG90b0lmRG9lc250RXhpc3QiLCJhbGJ1bUlkIiwicGhvdG9QYXJhbXMiLCJmaW5kT25lIiwibmV3SWQiLCJpbnNlcnQiLCJleGlmRGF0YSIsIl9pZCIsIiRzZXQiLCJpbnNlcnRLZXlzSW50b0FsYnVtIiwiczNwYXJhbXMiLCJsaXN0T2JqZWN0c1YyU3luYyIsImZvckVhY2giLCJDb250ZW50cyIsIm9iamVjdCIsInMzTG93UXVhbGl0eUZvbGRlck5hbWUiLCJpbmNsdWRlcyIsIktleSIsImlzVHJ1bmNhdGVkIiwiQ29udGludWF0aW9uVG9rZW4iLCJOZXh0Q29udGludWF0aW9uVG9rZW4iLCJpbnNlcnRPckZpbmRBbGJ1bSIsImFsYnVtTmFtZSIsImFsYnVtIiwibmFtZSIsInVwZGF0ZUZyb21Bd3MiLCJscyIsInRoZW4iLCJmb2xkZXJzIiwiZm9sZGVyIiwiUHJlZml4IiwiZm9sZGVyTmFtZSIsInRyaW0iLCJyZXBsYWNlIiwiZmVhdHVyZWRJbWFnZUtleSIsIm1ldGhvZHMiLCJBY2NvdW50cyIsImZvcmJpZENsaWVudEFjY291bnRDcmVhdGlvbiIsInVzZXJzIiwiZmluZCIsImNvdW50IiwiY3JlYXRlVXNlciIsInVzZXJuYW1lIiwicGFzc3dvcmQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE9BQU9DLE1BQVAsQ0FBYztBQUFDQyxVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJQyxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLGlCQUFKO0FBQXNCUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDRyxvQkFBa0JGLENBQWxCLEVBQW9CO0FBQUNFLHdCQUFrQkYsQ0FBbEI7QUFBb0I7O0FBQTFDLENBQW5ELEVBQStGLENBQS9GO0FBSWxNLE1BQU1KLFNBQVMsSUFBSUssTUFBTUUsVUFBVixDQUFxQixRQUFyQixDQUFmO0FBSlBULE9BQU9VLGFBQVAsQ0FLZVIsTUFMZjs7QUFPQSxJQUFJQyxPQUFPUSxRQUFYLEVBQXFCO0FBQ25CSCxvQkFBa0JOLE1BQWxCO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUNURCxJQUFJQyxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSU0sR0FBSjtBQUFRWixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDTyxNQUFJTixDQUFKLEVBQU07QUFBQ00sVUFBSU4sQ0FBSjtBQUFNOztBQUFkLENBQW5ELEVBQW1FLENBQW5FO0FBQXNFLElBQUlPLElBQUo7QUFBU2IsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDUyxVQUFRUixDQUFSLEVBQVU7QUFBQ08sV0FBS1AsQ0FBTDtBQUFPOztBQUFuQixDQUE5QixFQUFtRCxDQUFuRDs7QUFBc0QsSUFBSVMsQ0FBSjs7QUFBTWYsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDUyxVQUFRUixDQUFSLEVBQVU7QUFBQ1MsUUFBRVQsQ0FBRjtBQUFJOztBQUFoQixDQUEvQixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJVSxXQUFKO0FBQWdCaEIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDUyxVQUFRUixDQUFSLEVBQVU7QUFBQ1Usa0JBQVlWLENBQVo7QUFBYzs7QUFBMUIsQ0FBdEMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSVcsSUFBSjtBQUFTakIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGlCQUFSLENBQWIsRUFBd0M7QUFBQ1MsVUFBUVIsQ0FBUixFQUFVO0FBQUNXLFdBQUtYLENBQUw7QUFBTzs7QUFBbkIsQ0FBeEMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSVksRUFBSjtBQUFPbEIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGlCQUFSLENBQWIsRUFBd0M7QUFBQ1MsVUFBUVIsQ0FBUixFQUFVO0FBQUNZLFNBQUdaLENBQUg7QUFBSzs7QUFBakIsQ0FBeEMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSUosTUFBSjtBQUFXRixPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXBDLEVBQTBELENBQTFEO0FBQTZELElBQUlhLE1BQUo7QUFBV25CLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ2MsU0FBT2IsQ0FBUCxFQUFTO0FBQUNhLGFBQU9iLENBQVA7QUFBUzs7QUFBcEIsQ0FBcEMsRUFBMEQsQ0FBMUQ7O0FBY3ZrQixJQUFJLENBQUNILE9BQU9pQixRQUFQLENBQWdCUixHQUFyQixFQUEwQjtBQUN4QixRQUFPLElBQUlULE9BQU9rQixLQUFYLENBQWlCLGdDQUFqQixDQUFQO0FBQ0Q7O0FBRUQsTUFBTUMsYUFBYW5CLE9BQU9pQixRQUFQLENBQWdCUixHQUFoQixDQUFvQlcsWUFBdkM7QUFDQSxNQUFNQyxhQUFhckIsT0FBT2lCLFFBQVAsQ0FBZ0JSLEdBQWhCLENBQW9CYSxrQkFBdkM7QUFFQWIsSUFBSWMsTUFBSixDQUFXQyxNQUFYLENBQWtCO0FBQ2hCQyxlQUFhekIsT0FBT2lCLFFBQVAsQ0FBZ0JSLEdBQWhCLENBQW9CZ0IsV0FEakI7QUFFaEJDLG1CQUFpQjFCLE9BQU9pQixRQUFQLENBQWdCUixHQUFoQixDQUFvQmlCO0FBRnJCLENBQWxCO0FBS0EsTUFBTUMsS0FBSyxJQUFJbEIsSUFBSW1CLEVBQVIsRUFBWDtBQUNBLE1BQU1DLFNBQVNuQixLQUFLO0FBQUVvQixVQUFRWCxVQUFWO0FBQXNCUTtBQUF0QixDQUFMLENBQWY7QUFFQSxNQUFNSSxTQUFTO0FBQ2JDLFVBQVFiO0FBREssQ0FBZjs7QUFJQSxTQUFTYyxpQkFBVCxDQUEyQkMsSUFBM0IsRUFBaUM7QUFDL0IsU0FBTyxJQUFJQyxPQUFKLENBQVksVUFBU0MsT0FBVCxFQUFrQkMsTUFBbEIsRUFBMEI7QUFDM0MsVUFBTUMsZUFBZSxDQUFDLE9BQUQsRUFBVSxJQUFWLEVBQWdCLFdBQWhCLEVBQTZCLFdBQTdCLEVBQTBDLGVBQTFDLEVBQTJELFlBQTNELENBQXJCO0FBQ0F4QixTQUFLb0IsSUFBTCxFQUFXO0FBQUVLLGNBQVExQixXQUFWO0FBQXVCMkIsWUFBTUY7QUFBN0IsS0FBWCxFQUF3RCxDQUFDRyxLQUFELEVBQVFDLFFBQVIsS0FBcUI7QUFDM0UsVUFBSUQsS0FBSixFQUFXO0FBQ1RKLGVBQU9JLEtBQVA7QUFDRCxPQUZELE1BRU87QUFDTCxjQUFNRSxnQkFBZ0IsQ0FDcEIsaUJBRG9CLEVBRXBCLGlCQUZvQixFQUdwQixnQkFIb0IsQ0FBdEI7QUFLQVAsZ0JBQVF4QixFQUFFZ0MsSUFBRixDQUFPRixRQUFQLEVBQWlCQyxhQUFqQixDQUFSO0FBQ0Q7QUFDRixLQVhEO0FBWUQsR0FkTSxDQUFQO0FBZUQ7O0FBRUQsU0FBZUUsZ0JBQWYsQ0FBZ0NDLEtBQWhDO0FBQUEsa0NBQXVDO0FBQ3JDLFFBQUk7QUFDRixZQUFNQyxNQUFNQyxVQUFXLFVBQVNoRCxPQUFPaUIsUUFBUCxDQUFnQmdDLE1BQWhCLENBQXVCQyxhQUFjLElBQUdKLE1BQU1LLEdBQUksRUFBdEUsQ0FBWjtBQUNBLFlBQU1DLHlCQUFpQnJDLEdBQUc7QUFDeEJzQyxhQUFLTixHQURtQjtBQUV4Qk8sa0JBQVU7QUFGYyxPQUFILENBQWpCLENBQU47QUFJQSxZQUFNQyxxQkFBYXRCLGtCQUFrQm1CLFFBQWxCLENBQWIsQ0FBTjtBQUNBLGFBQU9HLElBQVA7QUFDRCxLQVJELENBUUUsT0FBT0MsR0FBUCxFQUFZO0FBQ1osYUFBTyxJQUFQO0FBQ0Q7QUFDRixHQVpEO0FBQUE7O0FBY0EsU0FBZUMsd0JBQWYsQ0FBd0NOLEdBQXhDLEVBQTZDTyxPQUE3QztBQUFBLGtDQUFzRDtBQUNwRCxVQUFNQyxjQUFjO0FBQ2xCUixTQURrQjtBQUVsQk87QUFGa0IsS0FBcEI7QUFJQSxRQUFJWixRQUFROUIsT0FBTzRDLE9BQVAsQ0FBZUQsV0FBZixDQUFaOztBQUNBLFFBQUksQ0FBQ2IsS0FBTCxFQUFZO0FBQ1YsWUFBTWUsUUFBUTdDLE9BQU84QyxNQUFQLENBQWNILFdBQWQsQ0FBZDtBQUNBYixjQUFROUIsT0FBTzRDLE9BQVAsQ0FBZUMsS0FBZixDQUFSO0FBQ0Q7O0FBQ0QsUUFBSSxDQUFDZixNQUFNSixRQUFYLEVBQXFCO0FBQ25CLFlBQU1xQix5QkFBaUJsQixpQkFBaUJDLEtBQWpCLENBQWpCLENBQU47QUFDQTlCLGFBQU9RLE1BQVAsQ0FBY3NCLE1BQU1rQixHQUFwQixFQUF5QjtBQUN2QkMsY0FBTTtBQUNKdkIsb0JBQVVxQjtBQUROO0FBRGlCLE9BQXpCO0FBS0Q7QUFDRixHQWxCRDtBQUFBOztBQW9CQSxTQUFTRyxtQkFBVCxDQUE2QkMsUUFBN0IsRUFBdUNULE9BQXZDLEVBQWdEO0FBQzlDLFFBQU14QixPQUFPUCxHQUFHeUMsaUJBQUgsQ0FBcUJELFFBQXJCLENBQWI7O0FBQ0F2RCxJQUFFeUQsT0FBRixDQUFVbkMsS0FBS29DLFFBQWYsRUFBeUIsVUFBU0MsTUFBVCxFQUFpQjtBQUN4QyxRQUFJdkUsT0FBT2lCLFFBQVAsQ0FBZ0JnQyxNQUFoQixDQUF1QnhDLEdBQXZCLENBQTJCK0Qsc0JBQS9CLEVBQXVEO0FBQ3JELFVBQUk1RCxFQUFFNkQsUUFBRixDQUFXRixPQUFPRyxHQUFsQixFQUF1QjFFLE9BQU9pQixRQUFQLENBQWdCZ0MsTUFBaEIsQ0FBdUJ4QyxHQUF2QixDQUEyQitELHNCQUFsRCxDQUFKLEVBQStFO0FBQzdFZixpQ0FBeUJjLE9BQU9HLEdBQWhDLEVBQXFDaEIsT0FBckM7QUFDRDtBQUNGLEtBSkQsTUFJTztBQUNMRCwrQkFBeUJjLE9BQU9HLEdBQWhDLEVBQXFDaEIsT0FBckM7QUFDRDtBQUNGLEdBUkQ7O0FBVUEsTUFBSXhCLEtBQUt5QyxXQUFULEVBQXNCO0FBQ3BCNUMsV0FBTzZDLGlCQUFQLEdBQTJCMUMsS0FBSzJDLHFCQUFoQztBQUNBWCx3QkFBb0JuQyxNQUFwQjtBQUNELEdBSEQsTUFHTyxJQUFJQSxPQUFPNkMsaUJBQVgsRUFBOEI7QUFDbkMsV0FBTzdDLE9BQU82QyxpQkFBZDtBQUNEO0FBQ0Y7O0FBRUQsU0FBU0UsaUJBQVQsQ0FBMkJDLFNBQTNCLEVBQXNDO0FBQ3BDLFFBQU1DLFFBQVFqRixPQUFPNkQsT0FBUCxDQUFlO0FBQUVxQixVQUFNRjtBQUFSLEdBQWYsQ0FBZDs7QUFDQSxNQUFJQyxLQUFKLEVBQVc7QUFDVCxXQUFPQSxNQUFNaEIsR0FBYjtBQUNEOztBQUNELFNBQU9qRSxPQUFPK0QsTUFBUCxDQUFjO0FBQUVtQixVQUFNRjtBQUFSLEdBQWQsQ0FBUDtBQUNEOztBQUVELFNBQWVHLGFBQWY7QUFBQSxrQ0FBK0I7QUFDN0Isa0JBQU1yRCxPQUFPc0QsRUFBUCxDQUFXLElBQUc5RCxVQUFXLEVBQXpCLEVBQTRCK0QsSUFBNUIsQ0FBa0NsRCxJQUFELElBQVU7QUFDL0N0QixRQUFFeUQsT0FBRixDQUFVbkMsS0FBS21ELE9BQWYsRUFBd0IsVUFBU0MsTUFBVCxFQUFpQjtBQUN2Q3ZELGVBQU93RCxNQUFQLEdBQWdCRCxNQUFoQjs7QUFDQSxjQUFNRSxhQUFhNUUsRUFBRTZFLElBQUYsQ0FBTzdFLEVBQUU4RSxPQUFGLENBQVVKLE1BQVYsRUFBa0JqRSxVQUFsQixFQUE4QixFQUE5QixDQUFQLEVBQTBDLEdBQTFDLENBQW5COztBQUNBLGNBQU1xQyxVQUFVb0Isa0JBQWtCVSxVQUFsQixDQUFoQjtBQUNBdEIsNEJBQW9CbkMsTUFBcEIsRUFBNEIyQixPQUE1QjtBQUNBLGNBQU1zQixRQUFRakYsT0FBTzZELE9BQVAsQ0FBZUYsT0FBZixDQUFkOztBQUNBLFlBQUksQ0FBQ3NCLE1BQU1XLGdCQUFYLEVBQTZCO0FBQzNCNUYsaUJBQU95QixNQUFQLENBQWM7QUFBRXdDLGlCQUFLTjtBQUFQLFdBQWQsRUFBZ0M7QUFDOUJPLGtCQUFNO0FBQ0owQixnQ0FBa0IzRSxPQUFPNEMsT0FBUCxDQUFlO0FBQUVGO0FBQUYsZUFBZixFQUE0QlA7QUFEMUM7QUFEd0IsV0FBaEM7QUFLRDtBQUNGLE9BYkQ7QUFjRCxLQWZLLENBQU47QUFnQkQsR0FqQkQ7QUFBQTs7QUFvQkEsSUFBSW5ELE9BQU9RLFFBQVgsRUFBcUI7QUFDbkJSLFNBQU80RixPQUFQLENBQWU7QUFDUCxnQkFBTjtBQUFBLHNDQUFxQjtBQUNuQixzQkFBTVYsZUFBTjtBQUNELE9BRkQ7QUFBQTs7QUFEYSxHQUFmO0FBS0QsQzs7Ozs7Ozs7Ozs7QUMzSURyRixPQUFPQyxNQUFQLENBQWM7QUFBQ2tCLFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUloQixNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLGlCQUFKO0FBQXNCUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDRyxvQkFBa0JGLENBQWxCLEVBQW9CO0FBQUNFLHdCQUFrQkYsQ0FBbEI7QUFBb0I7O0FBQTFDLENBQW5ELEVBQStGLENBQS9GO0FBS2xNLE1BQU1hLFNBQVMsSUFBSVosTUFBTUUsVUFBVixDQUFxQixRQUFyQixDQUFmO0FBTFBULE9BQU9VLGFBQVAsQ0FNZVMsTUFOZjs7QUFRQSxJQUFJaEIsT0FBT1EsUUFBWCxFQUFxQjtBQUNuQkgsb0JBQWtCVyxNQUFsQjtBQUNELEM7Ozs7Ozs7Ozs7O0FDVkQsSUFBSTZFLFFBQUo7QUFBYWhHLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUMyRixXQUFTMUYsQ0FBVCxFQUFXO0FBQUMwRixlQUFTMUYsQ0FBVDtBQUFXOztBQUF4QixDQUE3QyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJSCxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBR2xHLElBQUlILE9BQU9RLFFBQVgsRUFBcUI7QUFDbkJxRixXQUFTdEUsTUFBVCxDQUFnQjtBQUNkdUUsaUNBQTZCO0FBRGYsR0FBaEI7O0FBSUEsTUFBSTlGLE9BQU8rRixLQUFQLENBQWFDLElBQWIsR0FBb0JDLEtBQXBCLE9BQWdDLENBQXBDLEVBQXVDO0FBQ3JDSixhQUFTSyxVQUFULENBQW9CO0FBQ2xCQyxnQkFBVSxPQURRO0FBRWxCQyxnQkFBVTtBQUZRLEtBQXBCO0FBSUQ7QUFDRixDOzs7Ozs7Ozs7OztBQ2REdkcsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWI7QUFBK0NMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiO0FBQWtETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYjtBQUFrREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVDQUFSLENBQWIsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBwdWJsaXNoUGFnaW5hdGlvbiB9IGZyb20gJ21ldGVvci9rdXJvdW5pbjpwYWdpbmF0aW9uJztcblxuZXhwb3J0IGNvbnN0IEFsYnVtcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhbGJ1bXMnKTtcbmV4cG9ydCBkZWZhdWx0IEFsYnVtcztcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBwdWJsaXNoUGFnaW5hdGlvbihBbGJ1bXMpO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBV1MgfSBmcm9tICdtZXRlb3IvcGVlcmxpYnJhcnk6YXdzLXNkayc7XG5cbmltcG9ydCBzM2xzIGZyb20gJ3MzLWxzJztcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5pbXBvcnQgZXhpZlRvb2xCaW4gZnJvbSAnZGlzdC1leGlmdG9vbCc7XG5pbXBvcnQgRXhpZiBmcm9tICdzaW1wbGUtZXhpZnRvb2wnO1xuaW1wb3J0IHJwIGZyb20gJ3JlcXVlc3QtcHJvbWlzZSc7XG5cbmltcG9ydCB7IEFsYnVtcyB9IGZyb20gJy4vYWxidW1zLmpzJztcblxuaW1wb3J0IHsgUGhvdG9zIH0gZnJvbSAnLi9waG90b3MuanMnO1xuXG5cbmlmICghTWV0ZW9yLnNldHRpbmdzLkFXUykge1xuICB0aHJvdyAobmV3IE1ldGVvci5FcnJvcignQVdTIFNldHRpbmdzIG11c3QgYmUgc3BlY2lmaWVkJykpO1xufVxuXG5jb25zdCBidWNrZXROYW1lID0gTWV0ZW9yLnNldHRpbmdzLkFXUy5zM0J1Y2tldE5hbWU7XG5jb25zdCBtYWluRm9sZGVyID0gTWV0ZW9yLnNldHRpbmdzLkFXUy5zM0J1Y2tldE1haW5Gb2xkZXI7XG5cbkFXUy5jb25maWcudXBkYXRlKHtcbiAgYWNjZXNzS2V5SWQ6IE1ldGVvci5zZXR0aW5ncy5BV1MuYWNjZXNzS2V5SWQsXG4gIHNlY3JldEFjY2Vzc0tleTogTWV0ZW9yLnNldHRpbmdzLkFXUy5zZWNyZXRBY2Nlc3NLZXksXG59KTtcblxuY29uc3QgczMgPSBuZXcgQVdTLlMzKCk7XG5jb25zdCBsaXN0ZXIgPSBzM2xzKHsgYnVja2V0OiBidWNrZXROYW1lLCBzMyB9KTtcblxuY29uc3QgcGFyYW1zID0ge1xuICBCdWNrZXQ6IGJ1Y2tldE5hbWUsXG59O1xuXG5mdW5jdGlvbiBnZXRFWElGRnJvbUJpbmFyeShkYXRhKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbihyZXNvbHZlLCByZWplY3QpIHtcbiAgICBjb25zdCBleGlmVG9vbEFyZ3MgPSBbJy1qc29uJywgJy1zJywgJy1pcHRjOmFsbCcsICctZXhpZjphbGwnLCAnLWxvY2F0aW9uOmFsbCcsICcteG1wOmxhYmVsJ107XG4gICAgRXhpZihkYXRhLCB7IGJpbmFyeTogZXhpZlRvb2xCaW4sIGFyZ3M6IGV4aWZUb29sQXJncyB9LCAoZXJyb3IsIG1ldGFkYXRhKSA9PiB7XG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGtleXNUb0V4Y2x1ZGUgPSBbXG4gICAgICAgICAgJ1RodW1ibmFpbE9mZnNldCcsXG4gICAgICAgICAgJ1RodW1ibmFpbExlbmd0aCcsXG4gICAgICAgICAgJ1RodW1ibmFpbEltYWdlJyxcbiAgICAgICAgXTtcbiAgICAgICAgcmVzb2x2ZShfLm9taXQobWV0YWRhdGEsIGtleXNUb0V4Y2x1ZGUpKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdldEV4aWZEYXRhQXN5bmMocGhvdG8pIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB1cmwgPSBlbmNvZGVVUkkoYGh0dHA6Ly8ke01ldGVvci5zZXR0aW5ncy5wdWJsaWMucGhvdG9zQmFzZVVybH0vJHtwaG90by5rZXl9YCk7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBycCh7XG4gICAgICB1cmk6IHVybCxcbiAgICAgIGVuY29kaW5nOiBudWxsLFxuICAgIH0pO1xuICAgIGNvbnN0IHRhZ3MgPSBhd2FpdCBnZXRFWElGRnJvbUJpbmFyeShyZXNwb25zZSk7XG4gICAgcmV0dXJuIHRhZ3M7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGluc2VydFBob3RvSWZEb2VzbnRFeGlzdChrZXksIGFsYnVtSWQpIHtcbiAgY29uc3QgcGhvdG9QYXJhbXMgPSB7XG4gICAga2V5LFxuICAgIGFsYnVtSWQsXG4gIH07XG4gIGxldCBwaG90byA9IFBob3Rvcy5maW5kT25lKHBob3RvUGFyYW1zKTtcbiAgaWYgKCFwaG90bykge1xuICAgIGNvbnN0IG5ld0lkID0gUGhvdG9zLmluc2VydChwaG90b1BhcmFtcyk7XG4gICAgcGhvdG8gPSBQaG90b3MuZmluZE9uZShuZXdJZCk7XG4gIH1cbiAgaWYgKCFwaG90by5tZXRhZGF0YSkge1xuICAgIGNvbnN0IGV4aWZEYXRhID0gYXdhaXQgZ2V0RXhpZkRhdGFBc3luYyhwaG90byk7XG4gICAgUGhvdG9zLnVwZGF0ZShwaG90by5faWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgbWV0YWRhdGE6IGV4aWZEYXRhLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBpbnNlcnRLZXlzSW50b0FsYnVtKHMzcGFyYW1zLCBhbGJ1bUlkKSB7XG4gIGNvbnN0IGRhdGEgPSBzMy5saXN0T2JqZWN0c1YyU3luYyhzM3BhcmFtcyk7XG4gIF8uZm9yRWFjaChkYXRhLkNvbnRlbnRzLCBmdW5jdGlvbihvYmplY3QpIHtcbiAgICBpZiAoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5BV1MuczNMb3dRdWFsaXR5Rm9sZGVyTmFtZSkge1xuICAgICAgaWYgKF8uaW5jbHVkZXMob2JqZWN0LktleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5BV1MuczNMb3dRdWFsaXR5Rm9sZGVyTmFtZSkpIHtcbiAgICAgICAgaW5zZXJ0UGhvdG9JZkRvZXNudEV4aXN0KG9iamVjdC5LZXksIGFsYnVtSWQpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpbnNlcnRQaG90b0lmRG9lc250RXhpc3Qob2JqZWN0LktleSwgYWxidW1JZCk7XG4gICAgfVxuICB9KTtcblxuICBpZiAoZGF0YS5pc1RydW5jYXRlZCkge1xuICAgIHBhcmFtcy5Db250aW51YXRpb25Ub2tlbiA9IGRhdGEuTmV4dENvbnRpbnVhdGlvblRva2VuO1xuICAgIGluc2VydEtleXNJbnRvQWxidW0ocGFyYW1zKTtcbiAgfSBlbHNlIGlmIChwYXJhbXMuQ29udGludWF0aW9uVG9rZW4pIHtcbiAgICBkZWxldGUgcGFyYW1zLkNvbnRpbnVhdGlvblRva2VuO1xuICB9XG59XG5cbmZ1bmN0aW9uIGluc2VydE9yRmluZEFsYnVtKGFsYnVtTmFtZSkge1xuICBjb25zdCBhbGJ1bSA9IEFsYnVtcy5maW5kT25lKHsgbmFtZTogYWxidW1OYW1lIH0pO1xuICBpZiAoYWxidW0pIHtcbiAgICByZXR1cm4gYWxidW0uX2lkO1xuICB9XG4gIHJldHVybiBBbGJ1bXMuaW5zZXJ0KHsgbmFtZTogYWxidW1OYW1lIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVGcm9tQXdzKCkge1xuICBhd2FpdCBsaXN0ZXIubHMoYC8ke21haW5Gb2xkZXJ9YCkudGhlbigoZGF0YSkgPT4ge1xuICAgIF8uZm9yRWFjaChkYXRhLmZvbGRlcnMsIGZ1bmN0aW9uKGZvbGRlcikge1xuICAgICAgcGFyYW1zLlByZWZpeCA9IGZvbGRlcjtcbiAgICAgIGNvbnN0IGZvbGRlck5hbWUgPSBfLnRyaW0oXy5yZXBsYWNlKGZvbGRlciwgbWFpbkZvbGRlciwgJycpLCAnLycpO1xuICAgICAgY29uc3QgYWxidW1JZCA9IGluc2VydE9yRmluZEFsYnVtKGZvbGRlck5hbWUpO1xuICAgICAgaW5zZXJ0S2V5c0ludG9BbGJ1bShwYXJhbXMsIGFsYnVtSWQpO1xuICAgICAgY29uc3QgYWxidW0gPSBBbGJ1bXMuZmluZE9uZShhbGJ1bUlkKTtcbiAgICAgIGlmICghYWxidW0uZmVhdHVyZWRJbWFnZUtleSkge1xuICAgICAgICBBbGJ1bXMudXBkYXRlKHsgX2lkOiBhbGJ1bUlkIH0sIHtcbiAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICBmZWF0dXJlZEltYWdlS2V5OiBQaG90b3MuZmluZE9uZSh7IGFsYnVtSWQgfSkua2V5LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9KTtcbn1cblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIE1ldGVvci5tZXRob2RzKHtcbiAgICBhc3luYyAnYXdzLnVwZGF0ZScoKSB7XG4gICAgICBhd2FpdCB1cGRhdGVGcm9tQXdzKCk7XG4gICAgfSxcbiAgfSk7XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IHB1Ymxpc2hQYWdpbmF0aW9uIH0gZnJvbSAnbWV0ZW9yL2t1cm91bmluOnBhZ2luYXRpb24nO1xuXG5cbmV4cG9ydCBjb25zdCBQaG90b3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncGhvdG9zJyk7XG5leHBvcnQgZGVmYXVsdCBQaG90b3M7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgcHVibGlzaFBhZ2luYXRpb24oUGhvdG9zKTtcbn1cbiIsImltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgQWNjb3VudHMuY29uZmlnKHtcbiAgICBmb3JiaWRDbGllbnRBY2NvdW50Q3JlYXRpb246IHRydWUsXG4gIH0pO1xuXG4gIGlmIChNZXRlb3IudXNlcnMuZmluZCgpLmNvdW50KCkgPT09IDApIHtcbiAgICBBY2NvdW50cy5jcmVhdGVVc2VyKHtcbiAgICAgIHVzZXJuYW1lOiAnYWRtaW4nLFxuICAgICAgcGFzc3dvcmQ6ICdwYXNzd29yZCcsXG4gICAgfSk7XG4gIH1cbn1cbiIsImltcG9ydCAnLi4vaW1wb3J0cy9hcGkvYXdzLmpzJztcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvYWxidW1zLmpzJztcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvcGhvdG9zLmpzJztcbmltcG9ydCAnLi4vaW1wb3J0cy9zdGFydHVwL2FjY291bnRzLWNvbmZpZy5qcyc7XG4iXX0=
