var require = meteorInstall({"imports":{"api":{"albums.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// imports/api/albums.js                                                                         //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
module.export({
  Albums: () => Albums
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let publishPagination;
module.watch(require("meteor/kurounin:pagination"), {
  publishPagination(v) {
    publishPagination = v;
  }

}, 2);
const Albums = new Mongo.Collection('albums');

if (Meteor.isServer) {
  publishPagination(Albums);
}
///////////////////////////////////////////////////////////////////////////////////////////////////

},"aws.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// imports/api/aws.js                                                                            //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Albums;
module.watch(require("./albums.js"), {
  Albums(v) {
    Albums = v;
  }

}, 1);
let Photos;
module.watch(require("./photos.js"), {
  Photos(v) {
    Photos = v;
  }

}, 2);
let s3ls;
module.watch(require("s3-ls"), {
  default(v) {
    s3ls = v;
  }

}, 3);

let _;

module.watch(require("lodash"), {
  default(v) {
    _ = v;
  }

}, 4);
let exifToolBin;
module.watch(require("dist-exiftool"), {
  default(v) {
    exifToolBin = v;
  }

}, 5);
let Exif;
module.watch(require("simple-exiftool"), {
  default(v) {
    Exif = v;
  }

}, 6);
let rp;
module.watch(require("request-promise"), {
  default(v) {
    rp = v;
  }

}, 7);

if (Meteor.isServer) {
  if (!Meteor.settings.AWS) {
    throw new Meteor.Error("AWS Settings must be specified");
  }

  var bucketName = Meteor.settings.AWS.s3BucketName;
  var mainFolder = Meteor.settings.AWS.s3BucketMainFolder;
  AWS.config.update({
    accessKeyId: Meteor.settings.AWS.accessKeyId,
    secretAccessKey: Meteor.settings.AWS.secretAccessKey
  });
  var s3 = new AWS.S3();
  var lister = s3ls({
    bucket: bucketName,
    s3: s3
  });
  var params = {
    Bucket: bucketName
  };

  function insertKeysIntoAlbum(params, albumId) {
    var data = s3.listObjectsV2Sync(params);

    _.forEach(data.Contents, function (object) {
      if (Meteor.settings.public.AWS.s3LowQualityFolderName) {
        if (_.includes(object.Key, Meteor.settings.public.AWS.s3LowQualityFolderName)) {
          insertPhotoIfDoesntExist(object.Key, albumId);
        }
      } else {
        insertPhotoIfDoesntExist(object.Key, albumId);
      }
    });

    if (data.isTruncated) {
      params.ContinuationToken = data.NextContinuationToken;
      insertKeysIntoAlbum(params);
    } else {
      if (params.ContinuationToken) {
        delete params.ContinuationToken;
      }
    }
  }

  function insertPhotoIfDoesntExist(key, albumId) {
    return Promise.asyncApply(() => {
      var photoParams = {
        key: key,
        albumId: albumId
      };
      var photo = Photos.findOne(photoParams);

      if (!photo) {
        var newId = Photos.insert(photoParams);
        photo = Photos.findOne(newId);
      }

      if (!photo.metadata) {
        var exifData = Promise.await(getExifDataAsync(photo));
        Photos.update(photo._id, {
          $set: {
            metadata: exifData
          }
        });
      }
    });
  }

  function insertOrFindAlbum(albumName) {
    var album = Albums.findOne({
      name: albumName
    });

    if (album) {
      return album._id;
    } else {
      return Albums.insert({
        name: albumName
      });
    }
  }

  function updateFromAws() {
    console.log("aws update start");
    lister.ls("/" + mainFolder).then(data => {
      _.forEach(data.folders, function (folder) {
        params.Prefix = folder;

        var folderName = _.trim(_.replace(folder, mainFolder, ''), '/');

        var albumId = insertOrFindAlbum(folderName);
        insertKeysIntoAlbum(params, albumId);
        var album = Albums.findOne(albumId);

        if (!album.featuredImageKey) {
          Albums.update({
            _id: albumId
          }, {
            $set: {
              featuredImageKey: Photos.findOne({
                albumId: albumId
              }).key
            }
          });
        }
      });

      console.log("aws update complete");
    }).catch(console.error);
  }

  function getExifDataAsync(photo) {
    return Promise.asyncApply(() => {
      try {
        var url = encodeURI("http://" + Meteor.settings.public.photosBaseUrl + "/" + photo.key);
        var response = Promise.await(rp({
          uri: url,
          encoding: null
        }));
        var tags = Promise.await(getEXIFFromBinary(response));
        return tags;
      } catch (err) {
        console.log("Error: %s", err);
      }
    });
  }

  function getEXIFFromBinary(data) {
    return new Promise(function (resolve, reject) {
      Exif(data, {
        binary: exifToolBin,
        args: ["-json", "-s", "-iptc:all", "-exif:all"]
      }, (error, metadata) => {
        if (error) {
          reject(error);
        } else {
          var keysToExclude = ['ThumbnailOffset', 'ThumbnailLength', 'ThumbnailImage'];
          resolve(_.omit(metadata, keysToExclude));
        }
      });
    });
  }

  Meteor.methods({
    'aws.update'() {
      updateFromAws();
    }

  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////

},"photos.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// imports/api/photos.js                                                                         //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
module.export({
  Photos: () => Photos
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let publishPagination;
module.watch(require("meteor/kurounin:pagination"), {
  publishPagination(v) {
    publishPagination = v;
  }

}, 2);
const Photos = new Mongo.Collection('photos');

if (Meteor.isServer) {
  publishPagination(Photos);
}
///////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup":{"accounts-config.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// imports/startup/accounts-config.js                                                            //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 0);

if (Meteor.isServer) {
  Accounts.config({
    forbidClientAccountCreation: true
  });

  if (Meteor.users.find().count() === 0) {
    Accounts.createUser({
      username: 'admin',
      password: 'password'
    });
  }
}
///////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// server/main.js                                                                                //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
module.watch(require("../imports/api/aws.js"));
module.watch(require("../imports/api/albums.js"));
module.watch(require("../imports/api/photos.js"));
module.watch(require("../imports/startup/accounts-config.js"));
///////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWxidW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9hd3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Bob3Rvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2FjY291bnRzLWNvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiQWxidW1zIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1vbmdvIiwicHVibGlzaFBhZ2luYXRpb24iLCJDb2xsZWN0aW9uIiwiaXNTZXJ2ZXIiLCJQaG90b3MiLCJzM2xzIiwiZGVmYXVsdCIsIl8iLCJleGlmVG9vbEJpbiIsIkV4aWYiLCJycCIsInNldHRpbmdzIiwiQVdTIiwiRXJyb3IiLCJidWNrZXROYW1lIiwiczNCdWNrZXROYW1lIiwibWFpbkZvbGRlciIsInMzQnVja2V0TWFpbkZvbGRlciIsImNvbmZpZyIsInVwZGF0ZSIsImFjY2Vzc0tleUlkIiwic2VjcmV0QWNjZXNzS2V5IiwiczMiLCJTMyIsImxpc3RlciIsImJ1Y2tldCIsInBhcmFtcyIsIkJ1Y2tldCIsImluc2VydEtleXNJbnRvQWxidW0iLCJhbGJ1bUlkIiwiZGF0YSIsImxpc3RPYmplY3RzVjJTeW5jIiwiZm9yRWFjaCIsIkNvbnRlbnRzIiwib2JqZWN0IiwicHVibGljIiwiczNMb3dRdWFsaXR5Rm9sZGVyTmFtZSIsImluY2x1ZGVzIiwiS2V5IiwiaW5zZXJ0UGhvdG9JZkRvZXNudEV4aXN0IiwiaXNUcnVuY2F0ZWQiLCJDb250aW51YXRpb25Ub2tlbiIsIk5leHRDb250aW51YXRpb25Ub2tlbiIsImtleSIsInBob3RvUGFyYW1zIiwicGhvdG8iLCJmaW5kT25lIiwibmV3SWQiLCJpbnNlcnQiLCJtZXRhZGF0YSIsImV4aWZEYXRhIiwiZ2V0RXhpZkRhdGFBc3luYyIsIl9pZCIsIiRzZXQiLCJpbnNlcnRPckZpbmRBbGJ1bSIsImFsYnVtTmFtZSIsImFsYnVtIiwibmFtZSIsInVwZGF0ZUZyb21Bd3MiLCJjb25zb2xlIiwibG9nIiwibHMiLCJ0aGVuIiwiZm9sZGVycyIsImZvbGRlciIsIlByZWZpeCIsImZvbGRlck5hbWUiLCJ0cmltIiwicmVwbGFjZSIsImZlYXR1cmVkSW1hZ2VLZXkiLCJjYXRjaCIsImVycm9yIiwidXJsIiwiZW5jb2RlVVJJIiwicGhvdG9zQmFzZVVybCIsInJlc3BvbnNlIiwidXJpIiwiZW5jb2RpbmciLCJ0YWdzIiwiZ2V0RVhJRkZyb21CaW5hcnkiLCJlcnIiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImJpbmFyeSIsImFyZ3MiLCJrZXlzVG9FeGNsdWRlIiwib21pdCIsIm1ldGhvZHMiLCJBY2NvdW50cyIsImZvcmJpZENsaWVudEFjY291bnRDcmVhdGlvbiIsInVzZXJzIiwiZmluZCIsImNvdW50IiwiY3JlYXRlVXNlciIsInVzZXJuYW1lIiwicGFzc3dvcmQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE9BQU9DLE1BQVAsQ0FBYztBQUFDQyxVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJQyxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLGlCQUFKO0FBQXNCUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDRyxvQkFBa0JGLENBQWxCLEVBQW9CO0FBQUNFLHdCQUFrQkYsQ0FBbEI7QUFBb0I7O0FBQTFDLENBQW5ELEVBQStGLENBQS9GO0FBSWxNLE1BQU1KLFNBQVMsSUFBSUssTUFBTUUsVUFBVixDQUFxQixRQUFyQixDQUFmOztBQUVQLElBQUlOLE9BQU9PLFFBQVgsRUFBcUI7QUFDbkJGLG9CQUFrQk4sTUFBbEI7QUFDRCxDOzs7Ozs7Ozs7OztBQ1JELElBQUlDLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJSixNQUFKO0FBQVdGLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0gsU0FBT0ksQ0FBUCxFQUFTO0FBQUNKLGFBQU9JLENBQVA7QUFBUzs7QUFBcEIsQ0FBcEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSUssTUFBSjtBQUFXWCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNNLFNBQU9MLENBQVAsRUFBUztBQUFDSyxhQUFPTCxDQUFQO0FBQVM7O0FBQXBCLENBQXBDLEVBQTBELENBQTFEO0FBQTZELElBQUlNLElBQUo7QUFBU1osT0FBT0ksS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDUSxVQUFRUCxDQUFSLEVBQVU7QUFBQ00sV0FBS04sQ0FBTDtBQUFPOztBQUFuQixDQUE5QixFQUFtRCxDQUFuRDs7QUFBc0QsSUFBSVEsQ0FBSjs7QUFBTWQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDUSxVQUFRUCxDQUFSLEVBQVU7QUFBQ1EsUUFBRVIsQ0FBRjtBQUFJOztBQUFoQixDQUEvQixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJUyxXQUFKO0FBQWdCZixPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNRLFVBQVFQLENBQVIsRUFBVTtBQUFDUyxrQkFBWVQsQ0FBWjtBQUFjOztBQUExQixDQUF0QyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJVSxJQUFKO0FBQVNoQixPQUFPSSxLQUFQLENBQWFDLFFBQVEsaUJBQVIsQ0FBYixFQUF3QztBQUFDUSxVQUFRUCxDQUFSLEVBQVU7QUFBQ1UsV0FBS1YsQ0FBTDtBQUFPOztBQUFuQixDQUF4QyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJVyxFQUFKO0FBQU9qQixPQUFPSSxLQUFQLENBQWFDLFFBQVEsaUJBQVIsQ0FBYixFQUF3QztBQUFDUSxVQUFRUCxDQUFSLEVBQVU7QUFBQ1csU0FBR1gsQ0FBSDtBQUFLOztBQUFqQixDQUF4QyxFQUEyRCxDQUEzRDs7QUFjeGYsSUFBR0gsT0FBT08sUUFBVixFQUFtQjtBQUNqQixNQUFHLENBQUNQLE9BQU9lLFFBQVAsQ0FBZ0JDLEdBQXBCLEVBQXlCO0FBQ3ZCLFVBQU8sSUFBSWhCLE9BQU9pQixLQUFYLENBQWlCLGdDQUFqQixDQUFQO0FBQ0Q7O0FBRUQsTUFBSUMsYUFBYWxCLE9BQU9lLFFBQVAsQ0FBZ0JDLEdBQWhCLENBQW9CRyxZQUFyQztBQUNBLE1BQUlDLGFBQWFwQixPQUFPZSxRQUFQLENBQWdCQyxHQUFoQixDQUFvQkssa0JBQXJDO0FBRUFMLE1BQUlNLE1BQUosQ0FBV0MsTUFBWCxDQUFrQjtBQUNoQkMsaUJBQWF4QixPQUFPZSxRQUFQLENBQWdCQyxHQUFoQixDQUFvQlEsV0FEakI7QUFFaEJDLHFCQUFpQnpCLE9BQU9lLFFBQVAsQ0FBZ0JDLEdBQWhCLENBQW9CUztBQUZyQixHQUFsQjtBQUtBLE1BQUlDLEtBQUssSUFBSVYsSUFBSVcsRUFBUixFQUFUO0FBQ0EsTUFBSUMsU0FBU25CLEtBQUs7QUFBQ29CLFlBQVFYLFVBQVQ7QUFBcUJRLFFBQUlBO0FBQXpCLEdBQUwsQ0FBYjtBQUVBLE1BQUlJLFNBQVM7QUFDWEMsWUFBUWI7QUFERyxHQUFiOztBQUlBLFdBQVNjLG1CQUFULENBQTZCRixNQUE3QixFQUFxQ0csT0FBckMsRUFBOEM7QUFDNUMsUUFBSUMsT0FBT1IsR0FBR1MsaUJBQUgsQ0FBcUJMLE1BQXJCLENBQVg7O0FBQ0FuQixNQUFFeUIsT0FBRixDQUFVRixLQUFLRyxRQUFmLEVBQXlCLFVBQVNDLE1BQVQsRUFBaUI7QUFDeEMsVUFBR3RDLE9BQU9lLFFBQVAsQ0FBZ0J3QixNQUFoQixDQUF1QnZCLEdBQXZCLENBQTJCd0Isc0JBQTlCLEVBQXNEO0FBQ3BELFlBQUc3QixFQUFFOEIsUUFBRixDQUFXSCxPQUFPSSxHQUFsQixFQUF1QjFDLE9BQU9lLFFBQVAsQ0FBZ0J3QixNQUFoQixDQUF1QnZCLEdBQXZCLENBQTJCd0Isc0JBQWxELENBQUgsRUFBOEU7QUFDNUVHLG1DQUF5QkwsT0FBT0ksR0FBaEMsRUFBcUNULE9BQXJDO0FBQ0Q7QUFDRixPQUpELE1BSU87QUFDTFUsaUNBQXlCTCxPQUFPSSxHQUFoQyxFQUFxQ1QsT0FBckM7QUFDRDtBQUNGLEtBUkQ7O0FBVUEsUUFBR0MsS0FBS1UsV0FBUixFQUFxQjtBQUNuQmQsYUFBT2UsaUJBQVAsR0FBMkJYLEtBQUtZLHFCQUFoQztBQUNBZCwwQkFBb0JGLE1BQXBCO0FBQ0QsS0FIRCxNQUdPO0FBQ0wsVUFBR0EsT0FBT2UsaUJBQVYsRUFBNkI7QUFDM0IsZUFBT2YsT0FBT2UsaUJBQWQ7QUFDRDtBQUNGO0FBQ0Y7O0FBQ0QsV0FBZUYsd0JBQWYsQ0FBd0NJLEdBQXhDLEVBQTZDZCxPQUE3QztBQUFBLG9DQUFzRDtBQUNwRCxVQUFJZSxjQUFjO0FBQ2hCRCxhQUFLQSxHQURXO0FBRWhCZCxpQkFBU0E7QUFGTyxPQUFsQjtBQUlBLFVBQUlnQixRQUFRekMsT0FBTzBDLE9BQVAsQ0FBZUYsV0FBZixDQUFaOztBQUNBLFVBQUcsQ0FBQ0MsS0FBSixFQUFXO0FBQ1QsWUFBSUUsUUFBUTNDLE9BQU80QyxNQUFQLENBQWNKLFdBQWQsQ0FBWjtBQUNBQyxnQkFBUXpDLE9BQU8wQyxPQUFQLENBQWVDLEtBQWYsQ0FBUjtBQUNEOztBQUNELFVBQUcsQ0FBQ0YsTUFBTUksUUFBVixFQUFvQjtBQUNsQixZQUFJQyx5QkFBaUJDLGlCQUFpQk4sS0FBakIsQ0FBakIsQ0FBSjtBQUNBekMsZUFBT2UsTUFBUCxDQUFjMEIsTUFBTU8sR0FBcEIsRUFBeUI7QUFDdkJDLGdCQUFNO0FBQ0pKLHNCQUFVQztBQUROO0FBRGlCLFNBQXpCO0FBS0Q7QUFDRixLQWxCRDtBQUFBOztBQW1CQSxXQUFTSSxpQkFBVCxDQUEyQkMsU0FBM0IsRUFBc0M7QUFDcEMsUUFBSUMsUUFBUTdELE9BQU9tRCxPQUFQLENBQWU7QUFBQ1csWUFBTUY7QUFBUCxLQUFmLENBQVo7O0FBQ0EsUUFBR0MsS0FBSCxFQUFVO0FBQ1IsYUFBT0EsTUFBTUosR0FBYjtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU96RCxPQUFPcUQsTUFBUCxDQUFjO0FBQUNTLGNBQU1GO0FBQVAsT0FBZCxDQUFQO0FBQ0Q7QUFDRjs7QUFFRCxXQUFTRyxhQUFULEdBQXlCO0FBQ3ZCQyxZQUFRQyxHQUFSLENBQVksa0JBQVo7QUFDQXBDLFdBQU9xQyxFQUFQLENBQVUsTUFBSTdDLFVBQWQsRUFBMEI4QyxJQUExQixDQUFnQ2hDLElBQUQsSUFBVTtBQUN2Q3ZCLFFBQUV5QixPQUFGLENBQVVGLEtBQUtpQyxPQUFmLEVBQXdCLFVBQVNDLE1BQVQsRUFBaUI7QUFDdkN0QyxlQUFPdUMsTUFBUCxHQUFnQkQsTUFBaEI7O0FBQ0EsWUFBSUUsYUFBYTNELEVBQUU0RCxJQUFGLENBQU81RCxFQUFFNkQsT0FBRixDQUFVSixNQUFWLEVBQWtCaEQsVUFBbEIsRUFBOEIsRUFBOUIsQ0FBUCxFQUEwQyxHQUExQyxDQUFqQjs7QUFDQSxZQUFJYSxVQUFVeUIsa0JBQWtCWSxVQUFsQixDQUFkO0FBQ0F0Qyw0QkFBb0JGLE1BQXBCLEVBQTRCRyxPQUE1QjtBQUNBLFlBQUkyQixRQUFRN0QsT0FBT21ELE9BQVAsQ0FBZWpCLE9BQWYsQ0FBWjs7QUFDQSxZQUFHLENBQUMyQixNQUFNYSxnQkFBVixFQUE0QjtBQUMxQjFFLGlCQUFPd0IsTUFBUCxDQUFjO0FBQUNpQyxpQkFBSXZCO0FBQUwsV0FBZCxFQUE2QjtBQUFDd0Isa0JBQUs7QUFDakNnQixnQ0FBa0JqRSxPQUFPMEMsT0FBUCxDQUFlO0FBQUNqQix5QkFBU0E7QUFBVixlQUFmLEVBQW1DYztBQURwQjtBQUFOLFdBQTdCO0FBR0Q7QUFDRixPQVhEOztBQVlBZ0IsY0FBUUMsR0FBUixDQUFZLHFCQUFaO0FBQ0QsS0FkRCxFQWVDVSxLQWZELENBZU9YLFFBQVFZLEtBZmY7QUFnQkQ7O0FBRUQsV0FBZXBCLGdCQUFmLENBQWdDTixLQUFoQztBQUFBLG9DQUF1QztBQUNyQyxVQUFJO0FBQ0YsWUFBSTJCLE1BQU1DLFVBQVUsWUFBVTdFLE9BQU9lLFFBQVAsQ0FBZ0J3QixNQUFoQixDQUF1QnVDLGFBQWpDLEdBQStDLEdBQS9DLEdBQW1EN0IsTUFBTUYsR0FBbkUsQ0FBVjtBQUNBLFlBQUlnQyx5QkFBaUJqRSxHQUFHO0FBQ3RCa0UsZUFBS0osR0FEaUI7QUFFdEJLLG9CQUFVO0FBRlksU0FBSCxDQUFqQixDQUFKO0FBSUEsWUFBSUMscUJBQWFDLGtCQUFrQkosUUFBbEIsQ0FBYixDQUFKO0FBQ0EsZUFBT0csSUFBUDtBQUNELE9BUkQsQ0FRRSxPQUFNRSxHQUFOLEVBQVc7QUFDWHJCLGdCQUFRQyxHQUFSLENBQVksV0FBWixFQUF5Qm9CLEdBQXpCO0FBQ0Q7QUFDRixLQVpEO0FBQUE7O0FBY0EsV0FBU0QsaUJBQVQsQ0FBMkJqRCxJQUEzQixFQUFpQztBQUMvQixXQUFPLElBQUltRCxPQUFKLENBQVksVUFBU0MsT0FBVCxFQUFrQkMsTUFBbEIsRUFBMEI7QUFDM0MxRSxXQUFLcUIsSUFBTCxFQUFXO0FBQUNzRCxnQkFBUTVFLFdBQVQ7QUFBc0I2RSxjQUFLLENBQUMsT0FBRCxFQUFVLElBQVYsRUFBZ0IsV0FBaEIsRUFBNkIsV0FBN0I7QUFBM0IsT0FBWCxFQUFrRixDQUFDZCxLQUFELEVBQVF0QixRQUFSLEtBQXFCO0FBQ3JHLFlBQUlzQixLQUFKLEVBQVc7QUFDVFksaUJBQU9aLEtBQVA7QUFDRCxTQUZELE1BRU87QUFDTCxjQUFJZSxnQkFBZ0IsQ0FDbEIsaUJBRGtCLEVBRWxCLGlCQUZrQixFQUdsQixnQkFIa0IsQ0FBcEI7QUFLQUosa0JBQVEzRSxFQUFFZ0YsSUFBRixDQUFPdEMsUUFBUCxFQUFpQnFDLGFBQWpCLENBQVI7QUFDRDtBQUNGLE9BWEQ7QUFZRCxLQWJNLENBQVA7QUFjRDs7QUFFRDFGLFNBQU80RixPQUFQLENBQWU7QUFDYixtQkFBZTtBQUNiOUI7QUFDRDs7QUFIWSxHQUFmO0FBS0QsQzs7Ozs7Ozs7Ozs7QUMzSURqRSxPQUFPQyxNQUFQLENBQWM7QUFBQ1UsVUFBTyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSVIsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLEtBQUo7QUFBVVAsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxRQUFNRCxDQUFOLEVBQVE7QUFBQ0MsWUFBTUQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRSxpQkFBSjtBQUFzQlIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDRCQUFSLENBQWIsRUFBbUQ7QUFBQ0csb0JBQWtCRixDQUFsQixFQUFvQjtBQUFDRSx3QkFBa0JGLENBQWxCO0FBQW9COztBQUExQyxDQUFuRCxFQUErRixDQUEvRjtBQUlsTSxNQUFNSyxTQUFTLElBQUlKLE1BQU1FLFVBQVYsQ0FBcUIsUUFBckIsQ0FBZjs7QUFFUCxJQUFJTixPQUFPTyxRQUFYLEVBQXFCO0FBQ25CRixvQkFBa0JHLE1BQWxCO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUNSRCxJQUFJcUYsUUFBSjtBQUFhaEcsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRUFBNkM7QUFBQzJGLFdBQVMxRixDQUFULEVBQVc7QUFBQzBGLGVBQVMxRixDQUFUO0FBQVc7O0FBQXhCLENBQTdDLEVBQXVFLENBQXZFOztBQUNiLElBQUdILE9BQU9PLFFBQVYsRUFBb0I7QUFDbEJzRixXQUFTdkUsTUFBVCxDQUFnQjtBQUNkd0UsaUNBQTZCO0FBRGYsR0FBaEI7O0FBSUEsTUFBSzlGLE9BQU8rRixLQUFQLENBQWFDLElBQWIsR0FBb0JDLEtBQXBCLE9BQWdDLENBQXJDLEVBQXlDO0FBQ3JDSixhQUFTSyxVQUFULENBQW9CO0FBQ2hCQyxnQkFBVSxPQURNO0FBRWhCQyxnQkFBVTtBQUZNLEtBQXBCO0FBSUg7QUFDRixDOzs7Ozs7Ozs7OztBQ1pEdkcsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWI7QUFBK0NMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiO0FBQWtETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYjtBQUFrREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVDQUFSLENBQWIsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBwdWJsaXNoUGFnaW5hdGlvbiB9IGZyb20gJ21ldGVvci9rdXJvdW5pbjpwYWdpbmF0aW9uJztcblxuZXhwb3J0IGNvbnN0IEFsYnVtcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhbGJ1bXMnKTtcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBwdWJsaXNoUGFnaW5hdGlvbihBbGJ1bXMpXG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuaW1wb3J0IHsgQWxidW1zIH0gZnJvbSAnLi9hbGJ1bXMuanMnXG5cbmltcG9ydCB7IFBob3RvcyB9IGZyb20gJy4vcGhvdG9zLmpzJ1xuXG5pbXBvcnQgczNscyBmcm9tICdzMy1scydcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCdcbmltcG9ydCBleGlmVG9vbEJpbiBmcm9tICdkaXN0LWV4aWZ0b29sJ1xuaW1wb3J0IEV4aWYgZnJvbSAnc2ltcGxlLWV4aWZ0b29sJ1xuaW1wb3J0IHJwIGZyb20gJ3JlcXVlc3QtcHJvbWlzZSdcblxuXG5cbmlmKE1ldGVvci5pc1NlcnZlcil7XG4gIGlmKCFNZXRlb3Iuc2V0dGluZ3MuQVdTKSB7XG4gICAgdGhyb3cgKG5ldyBNZXRlb3IuRXJyb3IoXCJBV1MgU2V0dGluZ3MgbXVzdCBiZSBzcGVjaWZpZWRcIikpO1xuICB9XG5cbiAgdmFyIGJ1Y2tldE5hbWUgPSBNZXRlb3Iuc2V0dGluZ3MuQVdTLnMzQnVja2V0TmFtZTtcbiAgdmFyIG1haW5Gb2xkZXIgPSBNZXRlb3Iuc2V0dGluZ3MuQVdTLnMzQnVja2V0TWFpbkZvbGRlcjtcblxuICBBV1MuY29uZmlnLnVwZGF0ZSh7XG4gICAgYWNjZXNzS2V5SWQ6IE1ldGVvci5zZXR0aW5ncy5BV1MuYWNjZXNzS2V5SWQsXG4gICAgc2VjcmV0QWNjZXNzS2V5OiBNZXRlb3Iuc2V0dGluZ3MuQVdTLnNlY3JldEFjY2Vzc0tleSxcbiAgfSlcblxuICB2YXIgczMgPSBuZXcgQVdTLlMzKClcbiAgdmFyIGxpc3RlciA9IHMzbHMoe2J1Y2tldDogYnVja2V0TmFtZSwgczM6IHMzfSk7XG5cbiAgdmFyIHBhcmFtcyA9IHtcbiAgICBCdWNrZXQ6IGJ1Y2tldE5hbWVcbiAgfTtcblxuICBmdW5jdGlvbiBpbnNlcnRLZXlzSW50b0FsYnVtKHBhcmFtcywgYWxidW1JZCkge1xuICAgIHZhciBkYXRhID0gczMubGlzdE9iamVjdHNWMlN5bmMocGFyYW1zKTtcbiAgICBfLmZvckVhY2goZGF0YS5Db250ZW50cywgZnVuY3Rpb24ob2JqZWN0KSB7XG4gICAgICBpZihNZXRlb3Iuc2V0dGluZ3MucHVibGljLkFXUy5zM0xvd1F1YWxpdHlGb2xkZXJOYW1lKSB7XG4gICAgICAgIGlmKF8uaW5jbHVkZXMob2JqZWN0LktleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5BV1MuczNMb3dRdWFsaXR5Rm9sZGVyTmFtZSkpIHtcbiAgICAgICAgICBpbnNlcnRQaG90b0lmRG9lc250RXhpc3Qob2JqZWN0LktleSwgYWxidW1JZClcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaW5zZXJ0UGhvdG9JZkRvZXNudEV4aXN0KG9iamVjdC5LZXksIGFsYnVtSWQpXG4gICAgICB9XG4gICAgfSlcblxuICAgIGlmKGRhdGEuaXNUcnVuY2F0ZWQpIHtcbiAgICAgIHBhcmFtcy5Db250aW51YXRpb25Ub2tlbiA9IGRhdGEuTmV4dENvbnRpbnVhdGlvblRva2VuO1xuICAgICAgaW5zZXJ0S2V5c0ludG9BbGJ1bShwYXJhbXMpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZihwYXJhbXMuQ29udGludWF0aW9uVG9rZW4pIHtcbiAgICAgICAgZGVsZXRlIHBhcmFtcy5Db250aW51YXRpb25Ub2tlblxuICAgICAgfVxuICAgIH1cbiAgfVxuICBhc3luYyBmdW5jdGlvbiBpbnNlcnRQaG90b0lmRG9lc250RXhpc3Qoa2V5LCBhbGJ1bUlkKSB7XG4gICAgdmFyIHBob3RvUGFyYW1zID0ge1xuICAgICAga2V5OiBrZXksXG4gICAgICBhbGJ1bUlkOiBhbGJ1bUlkLFxuICAgIH1cbiAgICB2YXIgcGhvdG8gPSBQaG90b3MuZmluZE9uZShwaG90b1BhcmFtcyk7XG4gICAgaWYoIXBob3RvKSB7XG4gICAgICB2YXIgbmV3SWQgPSBQaG90b3MuaW5zZXJ0KHBob3RvUGFyYW1zKTtcbiAgICAgIHBob3RvID0gUGhvdG9zLmZpbmRPbmUobmV3SWQpO1xuICAgIH1cbiAgICBpZighcGhvdG8ubWV0YWRhdGEpIHtcbiAgICAgIHZhciBleGlmRGF0YSA9IGF3YWl0IGdldEV4aWZEYXRhQXN5bmMocGhvdG8pO1xuICAgICAgUGhvdG9zLnVwZGF0ZShwaG90by5faWQsIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgIG1ldGFkYXRhOiBleGlmRGF0YVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBpbnNlcnRPckZpbmRBbGJ1bShhbGJ1bU5hbWUpIHtcbiAgICB2YXIgYWxidW0gPSBBbGJ1bXMuZmluZE9uZSh7bmFtZTogYWxidW1OYW1lfSk7XG4gICAgaWYoYWxidW0pIHtcbiAgICAgIHJldHVybiBhbGJ1bS5faWQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBBbGJ1bXMuaW5zZXJ0KHtuYW1lOiBhbGJ1bU5hbWV9KVxuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHVwZGF0ZUZyb21Bd3MoKSB7XG4gICAgY29uc29sZS5sb2coXCJhd3MgdXBkYXRlIHN0YXJ0XCIpO1xuICAgIGxpc3Rlci5scyhcIi9cIittYWluRm9sZGVyKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICBfLmZvckVhY2goZGF0YS5mb2xkZXJzLCBmdW5jdGlvbihmb2xkZXIpIHtcbiAgICAgICAgcGFyYW1zLlByZWZpeCA9IGZvbGRlcjtcbiAgICAgICAgdmFyIGZvbGRlck5hbWUgPSBfLnRyaW0oXy5yZXBsYWNlKGZvbGRlciwgbWFpbkZvbGRlciwgJycpLCAnLycpO1xuICAgICAgICB2YXIgYWxidW1JZCA9IGluc2VydE9yRmluZEFsYnVtKGZvbGRlck5hbWUpO1xuICAgICAgICBpbnNlcnRLZXlzSW50b0FsYnVtKHBhcmFtcywgYWxidW1JZCk7XG4gICAgICAgIHZhciBhbGJ1bSA9IEFsYnVtcy5maW5kT25lKGFsYnVtSWQpXG4gICAgICAgIGlmKCFhbGJ1bS5mZWF0dXJlZEltYWdlS2V5KSB7XG4gICAgICAgICAgQWxidW1zLnVwZGF0ZSh7X2lkOmFsYnVtSWR9LCB7JHNldDp7XG4gICAgICAgICAgICBmZWF0dXJlZEltYWdlS2V5OiBQaG90b3MuZmluZE9uZSh7YWxidW1JZDogYWxidW1JZH0pLmtleVxuICAgICAgICAgIH19KTtcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIGNvbnNvbGUubG9nKFwiYXdzIHVwZGF0ZSBjb21wbGV0ZVwiKTtcbiAgICB9KVxuICAgIC5jYXRjaChjb25zb2xlLmVycm9yKTtcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGdldEV4aWZEYXRhQXN5bmMocGhvdG8pIHtcbiAgICB0cnkge1xuICAgICAgdmFyIHVybCA9IGVuY29kZVVSSShcImh0dHA6Ly9cIitNZXRlb3Iuc2V0dGluZ3MucHVibGljLnBob3Rvc0Jhc2VVcmwrXCIvXCIrcGhvdG8ua2V5KTtcbiAgICAgIHZhciByZXNwb25zZSA9IGF3YWl0IHJwKHtcbiAgICAgICAgdXJpOiB1cmwsXG4gICAgICAgIGVuY29kaW5nOiBudWxsLFxuICAgICAgfSk7XG4gICAgICB2YXIgdGFncyA9IGF3YWl0IGdldEVYSUZGcm9tQmluYXJ5KHJlc3BvbnNlKVxuICAgICAgcmV0dXJuIHRhZ3M7XG4gICAgfSBjYXRjaChlcnIpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3I6ICVzXCIsIGVycik7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gZ2V0RVhJRkZyb21CaW5hcnkoZGF0YSkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbihyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIEV4aWYoZGF0YSwge2JpbmFyeTogZXhpZlRvb2xCaW4sIGFyZ3M6W1wiLWpzb25cIiwgXCItc1wiLCBcIi1pcHRjOmFsbFwiLCBcIi1leGlmOmFsbFwiXX0sIChlcnJvciwgbWV0YWRhdGEpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2YXIga2V5c1RvRXhjbHVkZSA9IFtcbiAgICAgICAgICAgICdUaHVtYm5haWxPZmZzZXQnLFxuICAgICAgICAgICAgJ1RodW1ibmFpbExlbmd0aCcsXG4gICAgICAgICAgICAnVGh1bWJuYWlsSW1hZ2UnXG4gICAgICAgICAgXVxuICAgICAgICAgIHJlc29sdmUoXy5vbWl0KG1ldGFkYXRhLCBrZXlzVG9FeGNsdWRlKSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pXG4gIH1cblxuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgJ2F3cy51cGRhdGUnKCkge1xuICAgICAgdXBkYXRlRnJvbUF3cygpO1xuICAgIH0sXG4gIH0pXG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IHB1Ymxpc2hQYWdpbmF0aW9uIH0gZnJvbSAnbWV0ZW9yL2t1cm91bmluOnBhZ2luYXRpb24nO1xuXG5leHBvcnQgY29uc3QgUGhvdG9zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3Bob3RvcycpO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIHB1Ymxpc2hQYWdpbmF0aW9uKFBob3Rvcylcbn1cbiIsImltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuaWYoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIEFjY291bnRzLmNvbmZpZyh7XG4gICAgZm9yYmlkQ2xpZW50QWNjb3VudENyZWF0aW9uOiB0cnVlXG4gIH0pO1xuXG4gIGlmICggTWV0ZW9yLnVzZXJzLmZpbmQoKS5jb3VudCgpID09PSAwICkge1xuICAgICAgQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICAgICAgdXNlcm5hbWU6ICdhZG1pbicsXG4gICAgICAgICAgcGFzc3dvcmQ6ICdwYXNzd29yZCcsXG4gICAgICB9KTtcbiAgfVxufVxuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9hd3MuanMnXG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL2FsYnVtcy5qcyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL3Bob3Rvcy5qcyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvc3RhcnR1cC9hY2NvdW50cy1jb25maWcuanMnO1xuIl19
