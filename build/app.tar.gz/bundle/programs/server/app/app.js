var require = meteorInstall({"imports":{"api":{"albums.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// imports/api/albums.js                                                                                        //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.export({
  Albums: () => Albums
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let publishPagination;
module.watch(require("meteor/kurounin:pagination"), {
  publishPagination(v) {
    publishPagination = v;
  }

}, 2);
const Albums = new Mongo.Collection('albums');
module.exportDefault(Albums);

if (Meteor.isServer) {
  publishPagination(Albums);
  Meteor.methods({
    'albums.reset'() {
      if (!Meteor.userId()) {
        throw new Meteor.Error('Not authorized to delete albums');
      } else {
        Albums.remove({});
      }
    }

  });
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"aws.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// imports/api/aws.js                                                                                           //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let AWS;
module.watch(require("meteor/peerlibrary:aws-sdk"), {
  AWS(v) {
    AWS = v;
  }

}, 1);
let moment;
module.watch(require("meteor/momentjs:moment"), {
  moment(v) {
    moment = v;
  }

}, 2);
let s3ls;
module.watch(require("s3-ls"), {
  default(v) {
    s3ls = v;
  }

}, 3);

let _;

module.watch(require("lodash"), {
  default(v) {
    _ = v;
  }

}, 4);
let exifToolBin;
module.watch(require("dist-exiftool"), {
  default(v) {
    exifToolBin = v;
  }

}, 5);
let Exif;
module.watch(require("simple-exiftool"), {
  default(v) {
    Exif = v;
  }

}, 6);
let rp;
module.watch(require("request-promise"), {
  default(v) {
    rp = v;
  }

}, 7);
let Albums;
module.watch(require("./albums.js"), {
  Albums(v) {
    Albums = v;
  }

}, 8);
let Photos;
module.watch(require("./photos.js"), {
  Photos(v) {
    Photos = v;
  }

}, 9);

if (!Meteor.settings.AWS) {
  throw new Meteor.Error('AWS Settings must be specified');
}

const bucketName = Meteor.settings.AWS.s3BucketName;
const mainFolder = Meteor.settings.AWS.s3BucketMainFolder;
AWS.config.update({
  accessKeyId: Meteor.settings.AWS.accessKeyId,
  secretAccessKey: Meteor.settings.AWS.secretAccessKey
});
const s3 = new AWS.S3();
const lister = s3ls({
  bucket: bucketName,
  s3
});
const params = {
  Bucket: bucketName
};

function getEXIFFromBinary(data) {
  return new Promise(function (resolve, reject) {
    const exifToolArgs = ['-json', '-s', '-iptc:all', '-exif:all', '-location:all', '-xmp:label'];
    Exif(data, {
      binary: exifToolBin,
      args: exifToolArgs
    }, (error, metadata) => {
      if (error) {
        reject(error);
      } else {
        const keysToExclude = ['ThumbnailOffset', 'ThumbnailLength', 'ThumbnailImage'];
        resolve(_.omit(metadata, keysToExclude));
      }
    });
  });
}

function getExifDataAsync(photo) {
  return Promise.asyncApply(() => {
    try {
      const url = encodeURI(`http://${Meteor.settings.public.photosBaseUrl}/${photo.key}`);
      const response = Promise.await(rp({
        uri: url,
        encoding: null
      }));
      const tags = Promise.await(getEXIFFromBinary(response));
      return tags;
    } catch (err) {
      return null;
    }
  });
}

function insertPhotoIfDoesntExist(key, albumId) {
  return Promise.asyncApply(() => {
    const photoParams = {
      key,
      albumId
    };
    let photo = Photos.findOne(photoParams);

    if (!photo) {
      const newId = Photos.insert(photoParams);
      photo = Photos.findOne(newId);
    }

    if (!photo.metadata) {
      const exifData = Promise.await(getExifDataAsync(photo));
      Photos.update(photo._id, {
        $set: {
          metadata: exifData
        }
      });
    }
  });
}

function insertKeysIntoAlbum(s3params, albumId) {
  const data = s3.listObjectsV2Sync(s3params);

  _.forEach(data.Contents, function (object) {
    if (Meteor.settings.public.AWS.s3LowQualityFolderName) {
      if (_.includes(object.Key, Meteor.settings.public.AWS.s3LowQualityFolderName)) {
        insertPhotoIfDoesntExist(object.Key, albumId);
      }
    } else {
      insertPhotoIfDoesntExist(object.Key, albumId);
    }
  });

  if (data.isTruncated) {
    params.ContinuationToken = data.NextContinuationToken;
    insertKeysIntoAlbum(params);
  } else if (params.ContinuationToken) {
    delete params.ContinuationToken;
  }
}

function insertOrFindAlbum(albumName) {
  const album = Albums.findOne({
    name: albumName
  });

  if (album) {
    return album._id;
  }

  return Albums.insert({
    name: albumName
  });
}

function updateFromAws() {
  return Promise.asyncApply(() => {
    Promise.await(lister.ls(`/${mainFolder}`).then(data => {
      _.forEach(data.folders, function (folder) {
        params.Prefix = folder;

        const folderName = _.trim(_.replace(folder, mainFolder, ''), '/');

        const albumId = insertOrFindAlbum(folderName);
        insertKeysIntoAlbum(params, albumId);
        const album = Albums.findOne(albumId);
        const firstPhoto = Photos.find({
          albumId,
          'metadata.DateTimeOriginal': {
            $exists: true
          },
          key: {
            $regex: '.*jpg'
          }
        }, {
          sort: {
            'metadata.DateTimeOriginal': 1
          },
          limit: 1
        }).fetch();
        const firstPhotoDate = moment(firstPhoto[0].metadata.DateTimeOriginal, 'YYYY:MM:DD HH:mm:ss').toDate();

        if (!album.featuredImageKey) {
          Albums.update({
            _id: albumId
          }, {
            $set: {
              firstPhotoDate,
              featuredImageKey: Photos.findOne({
                albumId
              }).key
            }
          });
        } else {
          Albums.update({
            _id: albumId
          }, {
            $set: {
              firstPhotoDate
            }
          });
        }
      });
    }));
  });
}

if (Meteor.isServer) {
  Meteor.methods({
    'aws.update'() {
      return Promise.asyncApply(() => {
        if (!Meteor.userId()) {
          throw new Meteor.Error('Not authorized to delete photos');
        } else {
          Promise.await(updateFromAws());
        }
      });
    }

  });
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"photos.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// imports/api/photos.js                                                                                        //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.export({
  Photos: () => Photos
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let publishPagination;
module.watch(require("meteor/kurounin:pagination"), {
  publishPagination(v) {
    publishPagination = v;
  }

}, 2);
const Photos = new Mongo.Collection('photos');
module.exportDefault(Photos);

if (Meteor.isServer) {
  publishPagination(Photos);
  Meteor.methods({
    'photos.reset'() {
      if (!Meteor.userId()) {
        throw new Meteor.Error('Not authorized to delete photos');
      } else {
        Photos.remove({});
      }
    }

  });
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup":{"accounts-config.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// imports/startup/accounts-config.js                                                                           //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

if (Meteor.isServer) {
  Accounts.config({
    forbidClientAccountCreation: true
  });

  if (Meteor.users.find().count() === 0) {
    Accounts.createUser({
      username: 'admin',
      password: 'password'
    });
  }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/main.js                                                                                               //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.watch(require("../imports/api/aws.js"));
module.watch(require("../imports/api/albums.js"));
module.watch(require("../imports/api/photos.js"));
module.watch(require("../imports/startup/accounts-config.js"));
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWxidW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9hd3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Bob3Rvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2FjY291bnRzLWNvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiQWxidW1zIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1vbmdvIiwicHVibGlzaFBhZ2luYXRpb24iLCJDb2xsZWN0aW9uIiwiZXhwb3J0RGVmYXVsdCIsImlzU2VydmVyIiwibWV0aG9kcyIsInVzZXJJZCIsIkVycm9yIiwicmVtb3ZlIiwiQVdTIiwibW9tZW50IiwiczNscyIsImRlZmF1bHQiLCJfIiwiZXhpZlRvb2xCaW4iLCJFeGlmIiwicnAiLCJQaG90b3MiLCJzZXR0aW5ncyIsImJ1Y2tldE5hbWUiLCJzM0J1Y2tldE5hbWUiLCJtYWluRm9sZGVyIiwiczNCdWNrZXRNYWluRm9sZGVyIiwiY29uZmlnIiwidXBkYXRlIiwiYWNjZXNzS2V5SWQiLCJzZWNyZXRBY2Nlc3NLZXkiLCJzMyIsIlMzIiwibGlzdGVyIiwiYnVja2V0IiwicGFyYW1zIiwiQnVja2V0IiwiZ2V0RVhJRkZyb21CaW5hcnkiLCJkYXRhIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJleGlmVG9vbEFyZ3MiLCJiaW5hcnkiLCJhcmdzIiwiZXJyb3IiLCJtZXRhZGF0YSIsImtleXNUb0V4Y2x1ZGUiLCJvbWl0IiwiZ2V0RXhpZkRhdGFBc3luYyIsInBob3RvIiwidXJsIiwiZW5jb2RlVVJJIiwicHVibGljIiwicGhvdG9zQmFzZVVybCIsImtleSIsInJlc3BvbnNlIiwidXJpIiwiZW5jb2RpbmciLCJ0YWdzIiwiZXJyIiwiaW5zZXJ0UGhvdG9JZkRvZXNudEV4aXN0IiwiYWxidW1JZCIsInBob3RvUGFyYW1zIiwiZmluZE9uZSIsIm5ld0lkIiwiaW5zZXJ0IiwiZXhpZkRhdGEiLCJfaWQiLCIkc2V0IiwiaW5zZXJ0S2V5c0ludG9BbGJ1bSIsInMzcGFyYW1zIiwibGlzdE9iamVjdHNWMlN5bmMiLCJmb3JFYWNoIiwiQ29udGVudHMiLCJvYmplY3QiLCJzM0xvd1F1YWxpdHlGb2xkZXJOYW1lIiwiaW5jbHVkZXMiLCJLZXkiLCJpc1RydW5jYXRlZCIsIkNvbnRpbnVhdGlvblRva2VuIiwiTmV4dENvbnRpbnVhdGlvblRva2VuIiwiaW5zZXJ0T3JGaW5kQWxidW0iLCJhbGJ1bU5hbWUiLCJhbGJ1bSIsIm5hbWUiLCJ1cGRhdGVGcm9tQXdzIiwibHMiLCJ0aGVuIiwiZm9sZGVycyIsImZvbGRlciIsIlByZWZpeCIsImZvbGRlck5hbWUiLCJ0cmltIiwicmVwbGFjZSIsImZpcnN0UGhvdG8iLCJmaW5kIiwiJGV4aXN0cyIsIiRyZWdleCIsInNvcnQiLCJsaW1pdCIsImZldGNoIiwiZmlyc3RQaG90b0RhdGUiLCJEYXRlVGltZU9yaWdpbmFsIiwidG9EYXRlIiwiZmVhdHVyZWRJbWFnZUtleSIsIkFjY291bnRzIiwiZm9yYmlkQ2xpZW50QWNjb3VudENyZWF0aW9uIiwidXNlcnMiLCJjb3VudCIsImNyZWF0ZVVzZXIiLCJ1c2VybmFtZSIsInBhc3N3b3JkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsVUFBTyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSUMsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLEtBQUo7QUFBVVAsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxRQUFNRCxDQUFOLEVBQVE7QUFBQ0MsWUFBTUQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRSxpQkFBSjtBQUFzQlIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDRCQUFSLENBQWIsRUFBbUQ7QUFBQ0csb0JBQWtCRixDQUFsQixFQUFvQjtBQUFDRSx3QkFBa0JGLENBQWxCO0FBQW9COztBQUExQyxDQUFuRCxFQUErRixDQUEvRjtBQUlsTSxNQUFNSixTQUFTLElBQUlLLE1BQU1FLFVBQVYsQ0FBcUIsUUFBckIsQ0FBZjtBQUpQVCxPQUFPVSxhQUFQLENBS2VSLE1BTGY7O0FBT0EsSUFBSUMsT0FBT1EsUUFBWCxFQUFxQjtBQUNuQkgsb0JBQWtCTixNQUFsQjtBQUNBQyxTQUFPUyxPQUFQLENBQWU7QUFDYixxQkFBaUI7QUFDZixVQUFJLENBQUNULE9BQU9VLE1BQVAsRUFBTCxFQUFzQjtBQUNwQixjQUFNLElBQUlWLE9BQU9XLEtBQVgsQ0FBaUIsaUNBQWpCLENBQU47QUFDRCxPQUZELE1BRU87QUFDTFosZUFBT2EsTUFBUCxDQUFjLEVBQWQ7QUFDRDtBQUNGOztBQVBZLEdBQWY7QUFTRCxDOzs7Ozs7Ozs7OztBQ2xCRCxJQUFJWixNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSVUsR0FBSjtBQUFRaEIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDRCQUFSLENBQWIsRUFBbUQ7QUFBQ1csTUFBSVYsQ0FBSixFQUFNO0FBQUNVLFVBQUlWLENBQUo7QUFBTTs7QUFBZCxDQUFuRCxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJVyxNQUFKO0FBQVdqQixPQUFPSSxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDWSxTQUFPWCxDQUFQLEVBQVM7QUFBQ1csYUFBT1gsQ0FBUDtBQUFTOztBQUFwQixDQUEvQyxFQUFxRSxDQUFyRTtBQUF3RSxJQUFJWSxJQUFKO0FBQVNsQixPQUFPSSxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNjLFVBQVFiLENBQVIsRUFBVTtBQUFDWSxXQUFLWixDQUFMO0FBQU87O0FBQW5CLENBQTlCLEVBQW1ELENBQW5EOztBQUFzRCxJQUFJYyxDQUFKOztBQUFNcEIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDYyxVQUFRYixDQUFSLEVBQVU7QUFBQ2MsUUFBRWQsQ0FBRjtBQUFJOztBQUFoQixDQUEvQixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJZSxXQUFKO0FBQWdCckIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxVQUFRYixDQUFSLEVBQVU7QUFBQ2Usa0JBQVlmLENBQVo7QUFBYzs7QUFBMUIsQ0FBdEMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSWdCLElBQUo7QUFBU3RCLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxpQkFBUixDQUFiLEVBQXdDO0FBQUNjLFVBQVFiLENBQVIsRUFBVTtBQUFDZ0IsV0FBS2hCLENBQUw7QUFBTzs7QUFBbkIsQ0FBeEMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSWlCLEVBQUo7QUFBT3ZCLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxpQkFBUixDQUFiLEVBQXdDO0FBQUNjLFVBQVFiLENBQVIsRUFBVTtBQUFDaUIsU0FBR2pCLENBQUg7QUFBSzs7QUFBakIsQ0FBeEMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSUosTUFBSjtBQUFXRixPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXBDLEVBQTBELENBQTFEO0FBQTZELElBQUlrQixNQUFKO0FBQVd4QixPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNtQixTQUFPbEIsQ0FBUCxFQUFTO0FBQUNrQixhQUFPbEIsQ0FBUDtBQUFTOztBQUFwQixDQUFwQyxFQUEwRCxDQUExRDs7QUFlMXBCLElBQUksQ0FBQ0gsT0FBT3NCLFFBQVAsQ0FBZ0JULEdBQXJCLEVBQTBCO0FBQ3hCLFFBQU8sSUFBSWIsT0FBT1csS0FBWCxDQUFpQixnQ0FBakIsQ0FBUDtBQUNEOztBQUVELE1BQU1ZLGFBQWF2QixPQUFPc0IsUUFBUCxDQUFnQlQsR0FBaEIsQ0FBb0JXLFlBQXZDO0FBQ0EsTUFBTUMsYUFBYXpCLE9BQU9zQixRQUFQLENBQWdCVCxHQUFoQixDQUFvQmEsa0JBQXZDO0FBRUFiLElBQUljLE1BQUosQ0FBV0MsTUFBWCxDQUFrQjtBQUNoQkMsZUFBYTdCLE9BQU9zQixRQUFQLENBQWdCVCxHQUFoQixDQUFvQmdCLFdBRGpCO0FBRWhCQyxtQkFBaUI5QixPQUFPc0IsUUFBUCxDQUFnQlQsR0FBaEIsQ0FBb0JpQjtBQUZyQixDQUFsQjtBQUtBLE1BQU1DLEtBQUssSUFBSWxCLElBQUltQixFQUFSLEVBQVg7QUFDQSxNQUFNQyxTQUFTbEIsS0FBSztBQUFFbUIsVUFBUVgsVUFBVjtBQUFzQlE7QUFBdEIsQ0FBTCxDQUFmO0FBRUEsTUFBTUksU0FBUztBQUNiQyxVQUFRYjtBQURLLENBQWY7O0FBSUEsU0FBU2MsaUJBQVQsQ0FBMkJDLElBQTNCLEVBQWlDO0FBQy9CLFNBQU8sSUFBSUMsT0FBSixDQUFZLFVBQVNDLE9BQVQsRUFBa0JDLE1BQWxCLEVBQTBCO0FBQzNDLFVBQU1DLGVBQWUsQ0FBQyxPQUFELEVBQVUsSUFBVixFQUFnQixXQUFoQixFQUE2QixXQUE3QixFQUEwQyxlQUExQyxFQUEyRCxZQUEzRCxDQUFyQjtBQUNBdkIsU0FBS21CLElBQUwsRUFBVztBQUFFSyxjQUFRekIsV0FBVjtBQUF1QjBCLFlBQU1GO0FBQTdCLEtBQVgsRUFBd0QsQ0FBQ0csS0FBRCxFQUFRQyxRQUFSLEtBQXFCO0FBQzNFLFVBQUlELEtBQUosRUFBVztBQUNUSixlQUFPSSxLQUFQO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsY0FBTUUsZ0JBQWdCLENBQ3BCLGlCQURvQixFQUVwQixpQkFGb0IsRUFHcEIsZ0JBSG9CLENBQXRCO0FBS0FQLGdCQUFRdkIsRUFBRStCLElBQUYsQ0FBT0YsUUFBUCxFQUFpQkMsYUFBakIsQ0FBUjtBQUNEO0FBQ0YsS0FYRDtBQVlELEdBZE0sQ0FBUDtBQWVEOztBQUVELFNBQWVFLGdCQUFmLENBQWdDQyxLQUFoQztBQUFBLGtDQUF1QztBQUNyQyxRQUFJO0FBQ0YsWUFBTUMsTUFBTUMsVUFBVyxVQUFTcEQsT0FBT3NCLFFBQVAsQ0FBZ0IrQixNQUFoQixDQUF1QkMsYUFBYyxJQUFHSixNQUFNSyxHQUFJLEVBQXRFLENBQVo7QUFDQSxZQUFNQyx5QkFBaUJwQyxHQUFHO0FBQ3hCcUMsYUFBS04sR0FEbUI7QUFFeEJPLGtCQUFVO0FBRmMsT0FBSCxDQUFqQixDQUFOO0FBSUEsWUFBTUMscUJBQWF0QixrQkFBa0JtQixRQUFsQixDQUFiLENBQU47QUFDQSxhQUFPRyxJQUFQO0FBQ0QsS0FSRCxDQVFFLE9BQU9DLEdBQVAsRUFBWTtBQUNaLGFBQU8sSUFBUDtBQUNEO0FBQ0YsR0FaRDtBQUFBOztBQWNBLFNBQWVDLHdCQUFmLENBQXdDTixHQUF4QyxFQUE2Q08sT0FBN0M7QUFBQSxrQ0FBc0Q7QUFDcEQsVUFBTUMsY0FBYztBQUNsQlIsU0FEa0I7QUFFbEJPO0FBRmtCLEtBQXBCO0FBSUEsUUFBSVosUUFBUTdCLE9BQU8yQyxPQUFQLENBQWVELFdBQWYsQ0FBWjs7QUFDQSxRQUFJLENBQUNiLEtBQUwsRUFBWTtBQUNWLFlBQU1lLFFBQVE1QyxPQUFPNkMsTUFBUCxDQUFjSCxXQUFkLENBQWQ7QUFDQWIsY0FBUTdCLE9BQU8yQyxPQUFQLENBQWVDLEtBQWYsQ0FBUjtBQUNEOztBQUNELFFBQUksQ0FBQ2YsTUFBTUosUUFBWCxFQUFxQjtBQUNuQixZQUFNcUIseUJBQWlCbEIsaUJBQWlCQyxLQUFqQixDQUFqQixDQUFOO0FBQ0E3QixhQUFPTyxNQUFQLENBQWNzQixNQUFNa0IsR0FBcEIsRUFBeUI7QUFDdkJDLGNBQU07QUFDSnZCLG9CQUFVcUI7QUFETjtBQURpQixPQUF6QjtBQUtEO0FBQ0YsR0FsQkQ7QUFBQTs7QUFvQkEsU0FBU0csbUJBQVQsQ0FBNkJDLFFBQTdCLEVBQXVDVCxPQUF2QyxFQUFnRDtBQUM5QyxRQUFNeEIsT0FBT1AsR0FBR3lDLGlCQUFILENBQXFCRCxRQUFyQixDQUFiOztBQUNBdEQsSUFBRXdELE9BQUYsQ0FBVW5DLEtBQUtvQyxRQUFmLEVBQXlCLFVBQVNDLE1BQVQsRUFBaUI7QUFDeEMsUUFBSTNFLE9BQU9zQixRQUFQLENBQWdCK0IsTUFBaEIsQ0FBdUJ4QyxHQUF2QixDQUEyQitELHNCQUEvQixFQUF1RDtBQUNyRCxVQUFJM0QsRUFBRTRELFFBQUYsQ0FBV0YsT0FBT0csR0FBbEIsRUFBdUI5RSxPQUFPc0IsUUFBUCxDQUFnQitCLE1BQWhCLENBQXVCeEMsR0FBdkIsQ0FBMkIrRCxzQkFBbEQsQ0FBSixFQUErRTtBQUM3RWYsaUNBQXlCYyxPQUFPRyxHQUFoQyxFQUFxQ2hCLE9BQXJDO0FBQ0Q7QUFDRixLQUpELE1BSU87QUFDTEQsK0JBQXlCYyxPQUFPRyxHQUFoQyxFQUFxQ2hCLE9BQXJDO0FBQ0Q7QUFDRixHQVJEOztBQVVBLE1BQUl4QixLQUFLeUMsV0FBVCxFQUFzQjtBQUNwQjVDLFdBQU82QyxpQkFBUCxHQUEyQjFDLEtBQUsyQyxxQkFBaEM7QUFDQVgsd0JBQW9CbkMsTUFBcEI7QUFDRCxHQUhELE1BR08sSUFBSUEsT0FBTzZDLGlCQUFYLEVBQThCO0FBQ25DLFdBQU83QyxPQUFPNkMsaUJBQWQ7QUFDRDtBQUNGOztBQUVELFNBQVNFLGlCQUFULENBQTJCQyxTQUEzQixFQUFzQztBQUNwQyxRQUFNQyxRQUFRckYsT0FBT2lFLE9BQVAsQ0FBZTtBQUFFcUIsVUFBTUY7QUFBUixHQUFmLENBQWQ7O0FBQ0EsTUFBSUMsS0FBSixFQUFXO0FBQ1QsV0FBT0EsTUFBTWhCLEdBQWI7QUFDRDs7QUFDRCxTQUFPckUsT0FBT21FLE1BQVAsQ0FBYztBQUFFbUIsVUFBTUY7QUFBUixHQUFkLENBQVA7QUFDRDs7QUFFRCxTQUFlRyxhQUFmO0FBQUEsa0NBQStCO0FBQzdCLGtCQUFNckQsT0FBT3NELEVBQVAsQ0FBVyxJQUFHOUQsVUFBVyxFQUF6QixFQUE0QitELElBQTVCLENBQWtDbEQsSUFBRCxJQUFVO0FBQy9DckIsUUFBRXdELE9BQUYsQ0FBVW5DLEtBQUttRCxPQUFmLEVBQXdCLFVBQVNDLE1BQVQsRUFBaUI7QUFDdkN2RCxlQUFPd0QsTUFBUCxHQUFnQkQsTUFBaEI7O0FBQ0EsY0FBTUUsYUFBYTNFLEVBQUU0RSxJQUFGLENBQU81RSxFQUFFNkUsT0FBRixDQUFVSixNQUFWLEVBQWtCakUsVUFBbEIsRUFBOEIsRUFBOUIsQ0FBUCxFQUEwQyxHQUExQyxDQUFuQjs7QUFDQSxjQUFNcUMsVUFBVW9CLGtCQUFrQlUsVUFBbEIsQ0FBaEI7QUFDQXRCLDRCQUFvQm5DLE1BQXBCLEVBQTRCMkIsT0FBNUI7QUFDQSxjQUFNc0IsUUFBUXJGLE9BQU9pRSxPQUFQLENBQWVGLE9BQWYsQ0FBZDtBQUNBLGNBQU1pQyxhQUFhMUUsT0FBTzJFLElBQVAsQ0FBWTtBQUM3QmxDLGlCQUQ2QjtBQUU3Qix1Q0FBNkI7QUFBRW1DLHFCQUFTO0FBQVgsV0FGQTtBQUc3QjFDLGVBQUs7QUFBRTJDLG9CQUFRO0FBQVY7QUFId0IsU0FBWixFQUloQjtBQUNEQyxnQkFBTTtBQUNKLHlDQUE2QjtBQUR6QixXQURMO0FBSURDLGlCQUFPO0FBSk4sU0FKZ0IsRUFTaEJDLEtBVGdCLEVBQW5CO0FBVUEsY0FBTUMsaUJBQWlCeEYsT0FBT2lGLFdBQVcsQ0FBWCxFQUFjakQsUUFBZCxDQUF1QnlELGdCQUE5QixFQUFnRCxxQkFBaEQsRUFBdUVDLE1BQXZFLEVBQXZCOztBQUNBLFlBQUksQ0FBQ3BCLE1BQU1xQixnQkFBWCxFQUE2QjtBQUMzQjFHLGlCQUFPNkIsTUFBUCxDQUFjO0FBQUV3QyxpQkFBS047QUFBUCxXQUFkLEVBQWdDO0FBQzlCTyxrQkFBTTtBQUNKaUMsNEJBREk7QUFFSkcsZ0NBQWtCcEYsT0FBTzJDLE9BQVAsQ0FBZTtBQUFFRjtBQUFGLGVBQWYsRUFBNEJQO0FBRjFDO0FBRHdCLFdBQWhDO0FBTUQsU0FQRCxNQU9PO0FBQ0x4RCxpQkFBTzZCLE1BQVAsQ0FBYztBQUFFd0MsaUJBQUtOO0FBQVAsV0FBZCxFQUFnQztBQUM5Qk8sa0JBQU07QUFDSmlDO0FBREk7QUFEd0IsV0FBaEM7QUFLRDtBQUNGLE9BL0JEO0FBZ0NELEtBakNLLENBQU47QUFrQ0QsR0FuQ0Q7QUFBQTs7QUFzQ0EsSUFBSXRHLE9BQU9RLFFBQVgsRUFBcUI7QUFDbkJSLFNBQU9TLE9BQVAsQ0FBZTtBQUNQLGdCQUFOO0FBQUEsc0NBQXFCO0FBQ25CLFlBQUksQ0FBQ1QsT0FBT1UsTUFBUCxFQUFMLEVBQXNCO0FBQ3BCLGdCQUFNLElBQUlWLE9BQU9XLEtBQVgsQ0FBaUIsaUNBQWpCLENBQU47QUFDRCxTQUZELE1BRU87QUFDTCx3QkFBTTJFLGVBQU47QUFDRDtBQUNGLE9BTkQ7QUFBQTs7QUFEYSxHQUFmO0FBU0QsQzs7Ozs7Ozs7Ozs7QUNsS0R6RixPQUFPQyxNQUFQLENBQWM7QUFBQ3VCLFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUlyQixNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLGlCQUFKO0FBQXNCUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYixFQUFtRDtBQUFDRyxvQkFBa0JGLENBQWxCLEVBQW9CO0FBQUNFLHdCQUFrQkYsQ0FBbEI7QUFBb0I7O0FBQTFDLENBQW5ELEVBQStGLENBQS9GO0FBS2xNLE1BQU1rQixTQUFTLElBQUlqQixNQUFNRSxVQUFWLENBQXFCLFFBQXJCLENBQWY7QUFMUFQsT0FBT1UsYUFBUCxDQU1lYyxNQU5mOztBQVFBLElBQUlyQixPQUFPUSxRQUFYLEVBQXFCO0FBQ25CSCxvQkFBa0JnQixNQUFsQjtBQUNBckIsU0FBT1MsT0FBUCxDQUFlO0FBQ2IscUJBQWlCO0FBQ2YsVUFBSSxDQUFDVCxPQUFPVSxNQUFQLEVBQUwsRUFBc0I7QUFDcEIsY0FBTSxJQUFJVixPQUFPVyxLQUFYLENBQWlCLGlDQUFqQixDQUFOO0FBQ0QsT0FGRCxNQUVPO0FBQ0xVLGVBQU9ULE1BQVAsQ0FBYyxFQUFkO0FBQ0Q7QUFDRjs7QUFQWSxHQUFmO0FBU0QsQzs7Ozs7Ozs7Ozs7QUNuQkQsSUFBSThGLFFBQUo7QUFBYTdHLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUN3RyxXQUFTdkcsQ0FBVCxFQUFXO0FBQUN1RyxlQUFTdkcsQ0FBVDtBQUFXOztBQUF4QixDQUE3QyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJSCxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBR2xHLElBQUlILE9BQU9RLFFBQVgsRUFBcUI7QUFDbkJrRyxXQUFTL0UsTUFBVCxDQUFnQjtBQUNkZ0YsaUNBQTZCO0FBRGYsR0FBaEI7O0FBSUEsTUFBSTNHLE9BQU80RyxLQUFQLENBQWFaLElBQWIsR0FBb0JhLEtBQXBCLE9BQWdDLENBQXBDLEVBQXVDO0FBQ3JDSCxhQUFTSSxVQUFULENBQW9CO0FBQ2xCQyxnQkFBVSxPQURRO0FBRWxCQyxnQkFBVTtBQUZRLEtBQXBCO0FBSUQ7QUFDRixDOzs7Ozs7Ozs7OztBQ2REbkgsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWI7QUFBK0NMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiO0FBQWtETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYjtBQUFrREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVDQUFSLENBQWIsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBwdWJsaXNoUGFnaW5hdGlvbiB9IGZyb20gJ21ldGVvci9rdXJvdW5pbjpwYWdpbmF0aW9uJztcblxuZXhwb3J0IGNvbnN0IEFsYnVtcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhbGJ1bXMnKTtcbmV4cG9ydCBkZWZhdWx0IEFsYnVtcztcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBwdWJsaXNoUGFnaW5hdGlvbihBbGJ1bXMpO1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgJ2FsYnVtcy5yZXNldCcoKSB7XG4gICAgICBpZiAoIU1ldGVvci51c2VySWQoKSkge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdOb3QgYXV0aG9yaXplZCB0byBkZWxldGUgYWxidW1zJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBBbGJ1bXMucmVtb3ZlKHt9KTtcbiAgICAgIH1cbiAgICB9LFxuICB9KTtcbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQVdTIH0gZnJvbSAnbWV0ZW9yL3BlZXJsaWJyYXJ5OmF3cy1zZGsnO1xuaW1wb3J0IHsgbW9tZW50IH0gZnJvbSAnbWV0ZW9yL21vbWVudGpzOm1vbWVudCc7XG5cbmltcG9ydCBzM2xzIGZyb20gJ3MzLWxzJztcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5pbXBvcnQgZXhpZlRvb2xCaW4gZnJvbSAnZGlzdC1leGlmdG9vbCc7XG5pbXBvcnQgRXhpZiBmcm9tICdzaW1wbGUtZXhpZnRvb2wnO1xuaW1wb3J0IHJwIGZyb20gJ3JlcXVlc3QtcHJvbWlzZSc7XG5cbmltcG9ydCB7IEFsYnVtcyB9IGZyb20gJy4vYWxidW1zLmpzJztcblxuaW1wb3J0IHsgUGhvdG9zIH0gZnJvbSAnLi9waG90b3MuanMnO1xuXG5cbmlmICghTWV0ZW9yLnNldHRpbmdzLkFXUykge1xuICB0aHJvdyAobmV3IE1ldGVvci5FcnJvcignQVdTIFNldHRpbmdzIG11c3QgYmUgc3BlY2lmaWVkJykpO1xufVxuXG5jb25zdCBidWNrZXROYW1lID0gTWV0ZW9yLnNldHRpbmdzLkFXUy5zM0J1Y2tldE5hbWU7XG5jb25zdCBtYWluRm9sZGVyID0gTWV0ZW9yLnNldHRpbmdzLkFXUy5zM0J1Y2tldE1haW5Gb2xkZXI7XG5cbkFXUy5jb25maWcudXBkYXRlKHtcbiAgYWNjZXNzS2V5SWQ6IE1ldGVvci5zZXR0aW5ncy5BV1MuYWNjZXNzS2V5SWQsXG4gIHNlY3JldEFjY2Vzc0tleTogTWV0ZW9yLnNldHRpbmdzLkFXUy5zZWNyZXRBY2Nlc3NLZXksXG59KTtcblxuY29uc3QgczMgPSBuZXcgQVdTLlMzKCk7XG5jb25zdCBsaXN0ZXIgPSBzM2xzKHsgYnVja2V0OiBidWNrZXROYW1lLCBzMyB9KTtcblxuY29uc3QgcGFyYW1zID0ge1xuICBCdWNrZXQ6IGJ1Y2tldE5hbWUsXG59O1xuXG5mdW5jdGlvbiBnZXRFWElGRnJvbUJpbmFyeShkYXRhKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbihyZXNvbHZlLCByZWplY3QpIHtcbiAgICBjb25zdCBleGlmVG9vbEFyZ3MgPSBbJy1qc29uJywgJy1zJywgJy1pcHRjOmFsbCcsICctZXhpZjphbGwnLCAnLWxvY2F0aW9uOmFsbCcsICcteG1wOmxhYmVsJ107XG4gICAgRXhpZihkYXRhLCB7IGJpbmFyeTogZXhpZlRvb2xCaW4sIGFyZ3M6IGV4aWZUb29sQXJncyB9LCAoZXJyb3IsIG1ldGFkYXRhKSA9PiB7XG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGtleXNUb0V4Y2x1ZGUgPSBbXG4gICAgICAgICAgJ1RodW1ibmFpbE9mZnNldCcsXG4gICAgICAgICAgJ1RodW1ibmFpbExlbmd0aCcsXG4gICAgICAgICAgJ1RodW1ibmFpbEltYWdlJyxcbiAgICAgICAgXTtcbiAgICAgICAgcmVzb2x2ZShfLm9taXQobWV0YWRhdGEsIGtleXNUb0V4Y2x1ZGUpKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdldEV4aWZEYXRhQXN5bmMocGhvdG8pIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB1cmwgPSBlbmNvZGVVUkkoYGh0dHA6Ly8ke01ldGVvci5zZXR0aW5ncy5wdWJsaWMucGhvdG9zQmFzZVVybH0vJHtwaG90by5rZXl9YCk7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBycCh7XG4gICAgICB1cmk6IHVybCxcbiAgICAgIGVuY29kaW5nOiBudWxsLFxuICAgIH0pO1xuICAgIGNvbnN0IHRhZ3MgPSBhd2FpdCBnZXRFWElGRnJvbUJpbmFyeShyZXNwb25zZSk7XG4gICAgcmV0dXJuIHRhZ3M7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGluc2VydFBob3RvSWZEb2VzbnRFeGlzdChrZXksIGFsYnVtSWQpIHtcbiAgY29uc3QgcGhvdG9QYXJhbXMgPSB7XG4gICAga2V5LFxuICAgIGFsYnVtSWQsXG4gIH07XG4gIGxldCBwaG90byA9IFBob3Rvcy5maW5kT25lKHBob3RvUGFyYW1zKTtcbiAgaWYgKCFwaG90bykge1xuICAgIGNvbnN0IG5ld0lkID0gUGhvdG9zLmluc2VydChwaG90b1BhcmFtcyk7XG4gICAgcGhvdG8gPSBQaG90b3MuZmluZE9uZShuZXdJZCk7XG4gIH1cbiAgaWYgKCFwaG90by5tZXRhZGF0YSkge1xuICAgIGNvbnN0IGV4aWZEYXRhID0gYXdhaXQgZ2V0RXhpZkRhdGFBc3luYyhwaG90byk7XG4gICAgUGhvdG9zLnVwZGF0ZShwaG90by5faWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgbWV0YWRhdGE6IGV4aWZEYXRhLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBpbnNlcnRLZXlzSW50b0FsYnVtKHMzcGFyYW1zLCBhbGJ1bUlkKSB7XG4gIGNvbnN0IGRhdGEgPSBzMy5saXN0T2JqZWN0c1YyU3luYyhzM3BhcmFtcyk7XG4gIF8uZm9yRWFjaChkYXRhLkNvbnRlbnRzLCBmdW5jdGlvbihvYmplY3QpIHtcbiAgICBpZiAoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5BV1MuczNMb3dRdWFsaXR5Rm9sZGVyTmFtZSkge1xuICAgICAgaWYgKF8uaW5jbHVkZXMob2JqZWN0LktleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5BV1MuczNMb3dRdWFsaXR5Rm9sZGVyTmFtZSkpIHtcbiAgICAgICAgaW5zZXJ0UGhvdG9JZkRvZXNudEV4aXN0KG9iamVjdC5LZXksIGFsYnVtSWQpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpbnNlcnRQaG90b0lmRG9lc250RXhpc3Qob2JqZWN0LktleSwgYWxidW1JZCk7XG4gICAgfVxuICB9KTtcblxuICBpZiAoZGF0YS5pc1RydW5jYXRlZCkge1xuICAgIHBhcmFtcy5Db250aW51YXRpb25Ub2tlbiA9IGRhdGEuTmV4dENvbnRpbnVhdGlvblRva2VuO1xuICAgIGluc2VydEtleXNJbnRvQWxidW0ocGFyYW1zKTtcbiAgfSBlbHNlIGlmIChwYXJhbXMuQ29udGludWF0aW9uVG9rZW4pIHtcbiAgICBkZWxldGUgcGFyYW1zLkNvbnRpbnVhdGlvblRva2VuO1xuICB9XG59XG5cbmZ1bmN0aW9uIGluc2VydE9yRmluZEFsYnVtKGFsYnVtTmFtZSkge1xuICBjb25zdCBhbGJ1bSA9IEFsYnVtcy5maW5kT25lKHsgbmFtZTogYWxidW1OYW1lIH0pO1xuICBpZiAoYWxidW0pIHtcbiAgICByZXR1cm4gYWxidW0uX2lkO1xuICB9XG4gIHJldHVybiBBbGJ1bXMuaW5zZXJ0KHsgbmFtZTogYWxidW1OYW1lIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVGcm9tQXdzKCkge1xuICBhd2FpdCBsaXN0ZXIubHMoYC8ke21haW5Gb2xkZXJ9YCkudGhlbigoZGF0YSkgPT4ge1xuICAgIF8uZm9yRWFjaChkYXRhLmZvbGRlcnMsIGZ1bmN0aW9uKGZvbGRlcikge1xuICAgICAgcGFyYW1zLlByZWZpeCA9IGZvbGRlcjtcbiAgICAgIGNvbnN0IGZvbGRlck5hbWUgPSBfLnRyaW0oXy5yZXBsYWNlKGZvbGRlciwgbWFpbkZvbGRlciwgJycpLCAnLycpO1xuICAgICAgY29uc3QgYWxidW1JZCA9IGluc2VydE9yRmluZEFsYnVtKGZvbGRlck5hbWUpO1xuICAgICAgaW5zZXJ0S2V5c0ludG9BbGJ1bShwYXJhbXMsIGFsYnVtSWQpO1xuICAgICAgY29uc3QgYWxidW0gPSBBbGJ1bXMuZmluZE9uZShhbGJ1bUlkKTtcbiAgICAgIGNvbnN0IGZpcnN0UGhvdG8gPSBQaG90b3MuZmluZCh7XG4gICAgICAgIGFsYnVtSWQsXG4gICAgICAgICdtZXRhZGF0YS5EYXRlVGltZU9yaWdpbmFsJzogeyAkZXhpc3RzOiB0cnVlIH0sXG4gICAgICAgIGtleTogeyAkcmVnZXg6ICcuKmpwZycgfSxcbiAgICAgIH0sIHtcbiAgICAgICAgc29ydDoge1xuICAgICAgICAgICdtZXRhZGF0YS5EYXRlVGltZU9yaWdpbmFsJzogMSxcbiAgICAgICAgfSxcbiAgICAgICAgbGltaXQ6IDEsXG4gICAgICB9KS5mZXRjaCgpO1xuICAgICAgY29uc3QgZmlyc3RQaG90b0RhdGUgPSBtb21lbnQoZmlyc3RQaG90b1swXS5tZXRhZGF0YS5EYXRlVGltZU9yaWdpbmFsLCAnWVlZWTpNTTpERCBISDptbTpzcycpLnRvRGF0ZSgpO1xuICAgICAgaWYgKCFhbGJ1bS5mZWF0dXJlZEltYWdlS2V5KSB7XG4gICAgICAgIEFsYnVtcy51cGRhdGUoeyBfaWQ6IGFsYnVtSWQgfSwge1xuICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgIGZpcnN0UGhvdG9EYXRlLFxuICAgICAgICAgICAgZmVhdHVyZWRJbWFnZUtleTogUGhvdG9zLmZpbmRPbmUoeyBhbGJ1bUlkIH0pLmtleSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIEFsYnVtcy51cGRhdGUoeyBfaWQ6IGFsYnVtSWQgfSwge1xuICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgIGZpcnN0UGhvdG9EYXRlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9KTtcbn1cblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIE1ldGVvci5tZXRob2RzKHtcbiAgICBhc3luYyAnYXdzLnVwZGF0ZScoKSB7XG4gICAgICBpZiAoIU1ldGVvci51c2VySWQoKSkge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdOb3QgYXV0aG9yaXplZCB0byBkZWxldGUgcGhvdG9zJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCB1cGRhdGVGcm9tQXdzKCk7XG4gICAgICB9XG4gICAgfSxcbiAgfSk7XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IHB1Ymxpc2hQYWdpbmF0aW9uIH0gZnJvbSAnbWV0ZW9yL2t1cm91bmluOnBhZ2luYXRpb24nO1xuXG5cbmV4cG9ydCBjb25zdCBQaG90b3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncGhvdG9zJyk7XG5leHBvcnQgZGVmYXVsdCBQaG90b3M7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgcHVibGlzaFBhZ2luYXRpb24oUGhvdG9zKTtcbiAgTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdwaG90b3MucmVzZXQnKCkge1xuICAgICAgaWYgKCFNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignTm90IGF1dGhvcml6ZWQgdG8gZGVsZXRlIHBob3RvcycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgUGhvdG9zLnJlbW92ZSh7fSk7XG4gICAgICB9XG4gICAgfSxcbiAgfSk7XG59XG4iLCJpbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIEFjY291bnRzLmNvbmZpZyh7XG4gICAgZm9yYmlkQ2xpZW50QWNjb3VudENyZWF0aW9uOiB0cnVlLFxuICB9KTtcblxuICBpZiAoTWV0ZW9yLnVzZXJzLmZpbmQoKS5jb3VudCgpID09PSAwKSB7XG4gICAgQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICB1c2VybmFtZTogJ2FkbWluJyxcbiAgICAgIHBhc3N3b3JkOiAncGFzc3dvcmQnLFxuICAgIH0pO1xuICB9XG59XG4iLCJpbXBvcnQgJy4uL2ltcG9ydHMvYXBpL2F3cy5qcyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL2FsYnVtcy5qcyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL3Bob3Rvcy5qcyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvc3RhcnR1cC9hY2NvdW50cy1jb25maWcuanMnO1xuIl19
