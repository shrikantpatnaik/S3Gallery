(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Counts = Package['tmeasday:publish-counts'].Counts;
var publishCount = Package['tmeasday:publish-counts'].publishCount;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Autoupdate = Package.autoupdate.Autoupdate;

var require = meteorInstall({"node_modules":{"meteor":{"kurounin:pagination":{"server":{"pagination.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/kurounin_pagination/server/pagination.js                                                       //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
module.export({
  publishPagination: () => publishPagination
});

let _;

module.watch(require("meteor/underscore"), {
  _(v) {
    _ = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let check, Match;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 2);
let Counts;
module.watch(require("meteor/tmeasday:publish-counts"), {
  Counts(v) {
    Counts = v;
  }

}, 3);

function publishPagination(collection, settingsIn) {
  const settings = _.extend({
    name: collection._name,
    filters: {},

    dynamic_filters() {
      return {};
    }

  }, settingsIn || {});

  if (typeof settings.filters !== 'object') {
    // eslint-disable-next-line max-len
    throw new Meteor.Error(4001, 'Invalid filters provided. Server side filters need to be an object!');
  }

  if (typeof settings.dynamic_filters !== 'function') {
    // eslint-disable-next-line max-len
    throw new Meteor.Error(4002, 'Invalid dynamic filters provided. Server side dynamic filters needs to be a function!');
  }

  Meteor.publish(settings.name, function addPub(query = {}, optionsInput = {}) {
    check(query, Match.Optional(Object));
    check(optionsInput, Match.Optional(Object));
    const self = this;
    let options = optionsInput;
    let findQuery = {};
    let filters = [];

    if (!_.isEmpty(query)) {
      filters.push(query);
    }

    if (!_.isEmpty(settings.filters)) {
      filters.push(settings.filters);
    }

    const dynamic_filters = settings.dynamic_filters.call(self);

    if (typeof dynamic_filters === 'object') {
      if (!_.isEmpty(dynamic_filters)) {
        filters.push(dynamic_filters);
      }
    } else {
      // eslint-disable-next-line max-len
      throw new Meteor.Error(4002, 'Invalid dynamic filters return type. Server side dynamic filters needs to be a function that returns an object!');
    }

    if (typeof settings.transform_filters === 'function') {
      filters = settings.transform_filters.call(self, filters, options);
    }

    if (typeof settings.transform_options === 'function') {
      options = settings.transform_options.call(self, filters, options);
    }

    if (filters.length > 0) {
      if (filters.length > 1) {
        findQuery.$and = filters;
      } else {
        findQuery = filters[0];
      }
    }

    Counts.publish(self, `sub_count_${self._subscriptionId}`, collection.find(findQuery), {
      noReady: true,
      nonReactive: !options.reactive
    });

    if (options.debug) {
      console.log('Pagination', settings.name, options.reactive ? 'reactive' : 'non-reactive', 'publish', JSON.stringify(findQuery), JSON.stringify(options));
    }

    if (!options.reactive) {
      const docs = collection.find(findQuery, options).fetch();

      _.each(docs, function (doc) {
        self.added(collection._name, doc._id, doc);
        self.changed(collection._name, doc._id, {
          [`sub_${self._subscriptionId}`]: 1
        });
      });
    } else {
      const handle = collection.find(findQuery, options).observeChanges({
        added(id, fields) {
          self.added(collection._name, id, fields);
          self.changed(collection._name, id, {
            [`sub_${self._subscriptionId}`]: 1
          });
        },

        changed(id, fields) {
          self.changed(collection._name, id, fields);
        },

        removed(id) {
          self.removed(collection._name, id);
        }

      });
      self.onStop(() => {
        handle.stop();
      });
    }

    self.ready();
  });
}

class PaginationFactory {
  constructor(collection, settingsIn) {
    // eslint-disable-next-line max-len
    console.warn('Deprecated use of Meteor.Pagination. On server-side use publishPagination() function.');
    publishPagination(collection, settingsIn);
  }

}

Meteor.Pagination = PaginationFactory;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/kurounin:pagination/server/pagination.js");

/* Exports */
Package._define("kurounin:pagination", exports);

})();

//# sourceURL=meteor://💻app/packages/kurounin_pagination.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMva3Vyb3VuaW46cGFnaW5hdGlvbi9zZXJ2ZXIvcGFnaW5hdGlvbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJwdWJsaXNoUGFnaW5hdGlvbiIsIl8iLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiTWV0ZW9yIiwiY2hlY2siLCJNYXRjaCIsIkNvdW50cyIsImNvbGxlY3Rpb24iLCJzZXR0aW5nc0luIiwic2V0dGluZ3MiLCJleHRlbmQiLCJuYW1lIiwiX25hbWUiLCJmaWx0ZXJzIiwiZHluYW1pY19maWx0ZXJzIiwiRXJyb3IiLCJwdWJsaXNoIiwiYWRkUHViIiwicXVlcnkiLCJvcHRpb25zSW5wdXQiLCJPcHRpb25hbCIsIk9iamVjdCIsInNlbGYiLCJvcHRpb25zIiwiZmluZFF1ZXJ5IiwiaXNFbXB0eSIsInB1c2giLCJjYWxsIiwidHJhbnNmb3JtX2ZpbHRlcnMiLCJ0cmFuc2Zvcm1fb3B0aW9ucyIsImxlbmd0aCIsIiRhbmQiLCJfc3Vic2NyaXB0aW9uSWQiLCJmaW5kIiwibm9SZWFkeSIsIm5vblJlYWN0aXZlIiwicmVhY3RpdmUiLCJkZWJ1ZyIsImNvbnNvbGUiLCJsb2ciLCJKU09OIiwic3RyaW5naWZ5IiwiZG9jcyIsImZldGNoIiwiZWFjaCIsImRvYyIsImFkZGVkIiwiX2lkIiwiY2hhbmdlZCIsImhhbmRsZSIsIm9ic2VydmVDaGFuZ2VzIiwiaWQiLCJmaWVsZHMiLCJyZW1vdmVkIiwib25TdG9wIiwic3RvcCIsInJlYWR5IiwiUGFnaW5hdGlvbkZhY3RvcnkiLCJjb25zdHJ1Y3RvciIsIndhcm4iLCJQYWdpbmF0aW9uIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MscUJBQWtCLE1BQUlBO0FBQXZCLENBQWQ7O0FBQXlELElBQUlDLENBQUo7O0FBQU1ILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiLEVBQTBDO0FBQUNGLElBQUVHLENBQUYsRUFBSTtBQUFDSCxRQUFFRyxDQUFGO0FBQUk7O0FBQVYsQ0FBMUMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUMsTUFBSjtBQUFXUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNFLFNBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlFLEtBQUosRUFBVUMsS0FBVjtBQUFnQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQkcsUUFBTUgsQ0FBTixFQUFRO0FBQUNHLFlBQU1ILENBQU47QUFBUTs7QUFBcEMsQ0FBckMsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSUksTUFBSjtBQUFXVixPQUFPSSxLQUFQLENBQWFDLFFBQVEsZ0NBQVIsQ0FBYixFQUF1RDtBQUFDSyxTQUFPSixDQUFQLEVBQVM7QUFBQ0ksYUFBT0osQ0FBUDtBQUFTOztBQUFwQixDQUF2RCxFQUE2RSxDQUE3RTs7QUFLcFMsU0FBU0osaUJBQVQsQ0FBMkJTLFVBQTNCLEVBQXVDQyxVQUF2QyxFQUFtRDtBQUN4RCxRQUFNQyxXQUFXVixFQUFFVyxNQUFGLENBQ2Y7QUFDRUMsVUFBTUosV0FBV0ssS0FEbkI7QUFFRUMsYUFBUyxFQUZYOztBQUdFQyxzQkFBa0I7QUFDaEIsYUFBTyxFQUFQO0FBQ0Q7O0FBTEgsR0FEZSxFQVFmTixjQUFjLEVBUkMsQ0FBakI7O0FBV0EsTUFBSSxPQUFPQyxTQUFTSSxPQUFoQixLQUE0QixRQUFoQyxFQUEwQztBQUN4QztBQUNBLFVBQU0sSUFBSVYsT0FBT1ksS0FBWCxDQUFpQixJQUFqQixFQUF1QixxRUFBdkIsQ0FBTjtBQUNEOztBQUVELE1BQUksT0FBT04sU0FBU0ssZUFBaEIsS0FBb0MsVUFBeEMsRUFBb0Q7QUFDbEQ7QUFDQSxVQUFNLElBQUlYLE9BQU9ZLEtBQVgsQ0FBaUIsSUFBakIsRUFBdUIsdUZBQXZCLENBQU47QUFDRDs7QUFFRFosU0FBT2EsT0FBUCxDQUFlUCxTQUFTRSxJQUF4QixFQUE4QixTQUFTTSxNQUFULENBQWdCQyxRQUFRLEVBQXhCLEVBQTRCQyxlQUFlLEVBQTNDLEVBQStDO0FBQzNFZixVQUFNYyxLQUFOLEVBQWFiLE1BQU1lLFFBQU4sQ0FBZUMsTUFBZixDQUFiO0FBQ0FqQixVQUFNZSxZQUFOLEVBQW9CZCxNQUFNZSxRQUFOLENBQWVDLE1BQWYsQ0FBcEI7QUFFQSxVQUFNQyxPQUFPLElBQWI7QUFDQSxRQUFJQyxVQUFVSixZQUFkO0FBQ0EsUUFBSUssWUFBWSxFQUFoQjtBQUNBLFFBQUlYLFVBQVUsRUFBZDs7QUFFQSxRQUFJLENBQUNkLEVBQUUwQixPQUFGLENBQVVQLEtBQVYsQ0FBTCxFQUF1QjtBQUNyQkwsY0FBUWEsSUFBUixDQUFhUixLQUFiO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDbkIsRUFBRTBCLE9BQUYsQ0FBVWhCLFNBQVNJLE9BQW5CLENBQUwsRUFBa0M7QUFDaENBLGNBQVFhLElBQVIsQ0FBYWpCLFNBQVNJLE9BQXRCO0FBQ0Q7O0FBRUQsVUFBTUMsa0JBQWtCTCxTQUFTSyxlQUFULENBQXlCYSxJQUF6QixDQUE4QkwsSUFBOUIsQ0FBeEI7O0FBRUEsUUFBSSxPQUFPUixlQUFQLEtBQTJCLFFBQS9CLEVBQXlDO0FBQ3ZDLFVBQUksQ0FBQ2YsRUFBRTBCLE9BQUYsQ0FBVVgsZUFBVixDQUFMLEVBQWlDO0FBQy9CRCxnQkFBUWEsSUFBUixDQUFhWixlQUFiO0FBQ0Q7QUFDRixLQUpELE1BSU87QUFDTDtBQUNBLFlBQU0sSUFBSVgsT0FBT1ksS0FBWCxDQUFpQixJQUFqQixFQUF1QixpSEFBdkIsQ0FBTjtBQUNEOztBQUVELFFBQUksT0FBT04sU0FBU21CLGlCQUFoQixLQUFzQyxVQUExQyxFQUFzRDtBQUNwRGYsZ0JBQVVKLFNBQVNtQixpQkFBVCxDQUEyQkQsSUFBM0IsQ0FBZ0NMLElBQWhDLEVBQXNDVCxPQUF0QyxFQUErQ1UsT0FBL0MsQ0FBVjtBQUNEOztBQUVELFFBQUksT0FBT2QsU0FBU29CLGlCQUFoQixLQUFzQyxVQUExQyxFQUFzRDtBQUNwRE4sZ0JBQVVkLFNBQVNvQixpQkFBVCxDQUEyQkYsSUFBM0IsQ0FBZ0NMLElBQWhDLEVBQXNDVCxPQUF0QyxFQUErQ1UsT0FBL0MsQ0FBVjtBQUNEOztBQUVELFFBQUlWLFFBQVFpQixNQUFSLEdBQWlCLENBQXJCLEVBQXdCO0FBQ3RCLFVBQUlqQixRQUFRaUIsTUFBUixHQUFpQixDQUFyQixFQUF3QjtBQUN0Qk4sa0JBQVVPLElBQVYsR0FBaUJsQixPQUFqQjtBQUNELE9BRkQsTUFFTztBQUNMVyxvQkFBWVgsUUFBUSxDQUFSLENBQVo7QUFDRDtBQUNGOztBQUVEUCxXQUFPVSxPQUFQLENBQ0VNLElBREYsRUFFRyxhQUFZQSxLQUFLVSxlQUFnQixFQUZwQyxFQUdFekIsV0FBVzBCLElBQVgsQ0FBZ0JULFNBQWhCLENBSEYsRUFJRTtBQUNFVSxlQUFTLElBRFg7QUFFRUMsbUJBQWEsQ0FBQ1osUUFBUWE7QUFGeEIsS0FKRjs7QUFVQSxRQUFJYixRQUFRYyxLQUFaLEVBQW1CO0FBQ2pCQyxjQUFRQyxHQUFSLENBQ0UsWUFERixFQUVFOUIsU0FBU0UsSUFGWCxFQUdFWSxRQUFRYSxRQUFSLEdBQW1CLFVBQW5CLEdBQWdDLGNBSGxDLEVBSUUsU0FKRixFQUtFSSxLQUFLQyxTQUFMLENBQWVqQixTQUFmLENBTEYsRUFNRWdCLEtBQUtDLFNBQUwsQ0FBZWxCLE9BQWYsQ0FORjtBQVFEOztBQUVELFFBQUksQ0FBQ0EsUUFBUWEsUUFBYixFQUF1QjtBQUNyQixZQUFNTSxPQUFPbkMsV0FBVzBCLElBQVgsQ0FBZ0JULFNBQWhCLEVBQTJCRCxPQUEzQixFQUFvQ29CLEtBQXBDLEVBQWI7O0FBRUE1QyxRQUFFNkMsSUFBRixDQUFPRixJQUFQLEVBQWEsVUFBU0csR0FBVCxFQUFjO0FBQ3JCdkIsYUFBS3dCLEtBQUwsQ0FBV3ZDLFdBQVdLLEtBQXRCLEVBQTZCaUMsSUFBSUUsR0FBakMsRUFBc0NGLEdBQXRDO0FBRUF2QixhQUFLMEIsT0FBTCxDQUFhekMsV0FBV0ssS0FBeEIsRUFBK0JpQyxJQUFJRSxHQUFuQyxFQUF3QztBQUFDLFdBQUUsT0FBTXpCLEtBQUtVLGVBQWdCLEVBQTdCLEdBQWlDO0FBQWxDLFNBQXhDO0FBQ0wsT0FKRDtBQUtELEtBUkQsTUFRTztBQUNILFlBQU1pQixTQUFTMUMsV0FBVzBCLElBQVgsQ0FBZ0JULFNBQWhCLEVBQTJCRCxPQUEzQixFQUFvQzJCLGNBQXBDLENBQW1EO0FBQzlESixjQUFNSyxFQUFOLEVBQVVDLE1BQVYsRUFBa0I7QUFDZDlCLGVBQUt3QixLQUFMLENBQVd2QyxXQUFXSyxLQUF0QixFQUE2QnVDLEVBQTdCLEVBQWlDQyxNQUFqQztBQUVBOUIsZUFBSzBCLE9BQUwsQ0FBYXpDLFdBQVdLLEtBQXhCLEVBQStCdUMsRUFBL0IsRUFBbUM7QUFBQyxhQUFFLE9BQU03QixLQUFLVSxlQUFnQixFQUE3QixHQUFpQztBQUFsQyxXQUFuQztBQUNILFNBTDZEOztBQU05RGdCLGdCQUFRRyxFQUFSLEVBQVlDLE1BQVosRUFBb0I7QUFDaEI5QixlQUFLMEIsT0FBTCxDQUFhekMsV0FBV0ssS0FBeEIsRUFBK0J1QyxFQUEvQixFQUFtQ0MsTUFBbkM7QUFDSCxTQVI2RDs7QUFTOURDLGdCQUFRRixFQUFSLEVBQVk7QUFDUjdCLGVBQUsrQixPQUFMLENBQWE5QyxXQUFXSyxLQUF4QixFQUErQnVDLEVBQS9CO0FBQ0g7O0FBWDZELE9BQW5ELENBQWY7QUFjQTdCLFdBQUtnQyxNQUFMLENBQVksTUFBTTtBQUNkTCxlQUFPTSxJQUFQO0FBQ0gsT0FGRDtBQUdIOztBQUVEakMsU0FBS2tDLEtBQUw7QUFDRCxHQTlGRDtBQStGRDs7QUFFRCxNQUFNQyxpQkFBTixDQUF3QjtBQUN0QkMsY0FBWW5ELFVBQVosRUFBd0JDLFVBQXhCLEVBQW9DO0FBQ2xDO0FBQ0E4QixZQUFRcUIsSUFBUixDQUFhLHVGQUFiO0FBRUE3RCxzQkFBa0JTLFVBQWxCLEVBQThCQyxVQUE5QjtBQUNEOztBQU5xQjs7QUFTeEJMLE9BQU95RCxVQUFQLEdBQW9CSCxpQkFBcEIsQyIsImZpbGUiOiIvcGFja2FnZXMva3Vyb3VuaW5fcGFnaW5hdGlvbi5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSc7XHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBjaGVjaywgTWF0Y2ggfSBmcm9tICdtZXRlb3IvY2hlY2snO1xyXG5pbXBvcnQgeyBDb3VudHMgfSBmcm9tICdtZXRlb3IvdG1lYXNkYXk6cHVibGlzaC1jb3VudHMnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHB1Ymxpc2hQYWdpbmF0aW9uKGNvbGxlY3Rpb24sIHNldHRpbmdzSW4pIHtcclxuICBjb25zdCBzZXR0aW5ncyA9IF8uZXh0ZW5kKFxyXG4gICAge1xyXG4gICAgICBuYW1lOiBjb2xsZWN0aW9uLl9uYW1lLFxyXG4gICAgICBmaWx0ZXJzOiB7fSxcclxuICAgICAgZHluYW1pY19maWx0ZXJzKCkge1xyXG4gICAgICAgIHJldHVybiB7fTtcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBzZXR0aW5nc0luIHx8IHt9XHJcbiAgKTtcclxuXHJcbiAgaWYgKHR5cGVvZiBzZXR0aW5ncy5maWx0ZXJzICE9PSAnb2JqZWN0Jykge1xyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG1heC1sZW5cclxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwMSwgJ0ludmFsaWQgZmlsdGVycyBwcm92aWRlZC4gU2VydmVyIHNpZGUgZmlsdGVycyBuZWVkIHRvIGJlIGFuIG9iamVjdCEnKTtcclxuICB9XHJcblxyXG4gIGlmICh0eXBlb2Ygc2V0dGluZ3MuZHluYW1pY19maWx0ZXJzICE9PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LWxlblxyXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAyLCAnSW52YWxpZCBkeW5hbWljIGZpbHRlcnMgcHJvdmlkZWQuIFNlcnZlciBzaWRlIGR5bmFtaWMgZmlsdGVycyBuZWVkcyB0byBiZSBhIGZ1bmN0aW9uIScpO1xyXG4gIH1cclxuXHJcbiAgTWV0ZW9yLnB1Ymxpc2goc2V0dGluZ3MubmFtZSwgZnVuY3Rpb24gYWRkUHViKHF1ZXJ5ID0ge30sIG9wdGlvbnNJbnB1dCA9IHt9KSB7XHJcbiAgICBjaGVjayhxdWVyeSwgTWF0Y2guT3B0aW9uYWwoT2JqZWN0KSk7XHJcbiAgICBjaGVjayhvcHRpb25zSW5wdXQsIE1hdGNoLk9wdGlvbmFsKE9iamVjdCkpO1xyXG5cclxuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xyXG4gICAgbGV0IG9wdGlvbnMgPSBvcHRpb25zSW5wdXQ7XHJcbiAgICBsZXQgZmluZFF1ZXJ5ID0ge307XHJcbiAgICBsZXQgZmlsdGVycyA9IFtdO1xyXG5cclxuICAgIGlmICghXy5pc0VtcHR5KHF1ZXJ5KSkge1xyXG4gICAgICBmaWx0ZXJzLnB1c2gocXVlcnkpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghXy5pc0VtcHR5KHNldHRpbmdzLmZpbHRlcnMpKSB7XHJcbiAgICAgIGZpbHRlcnMucHVzaChzZXR0aW5ncy5maWx0ZXJzKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBkeW5hbWljX2ZpbHRlcnMgPSBzZXR0aW5ncy5keW5hbWljX2ZpbHRlcnMuY2FsbChzZWxmKTtcclxuXHJcbiAgICBpZiAodHlwZW9mIGR5bmFtaWNfZmlsdGVycyA9PT0gJ29iamVjdCcpIHtcclxuICAgICAgaWYgKCFfLmlzRW1wdHkoZHluYW1pY19maWx0ZXJzKSkge1xyXG4gICAgICAgIGZpbHRlcnMucHVzaChkeW5hbWljX2ZpbHRlcnMpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LWxlblxyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMDIsICdJbnZhbGlkIGR5bmFtaWMgZmlsdGVycyByZXR1cm4gdHlwZS4gU2VydmVyIHNpZGUgZHluYW1pYyBmaWx0ZXJzIG5lZWRzIHRvIGJlIGEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIGFuIG9iamVjdCEnKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAodHlwZW9mIHNldHRpbmdzLnRyYW5zZm9ybV9maWx0ZXJzID09PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgIGZpbHRlcnMgPSBzZXR0aW5ncy50cmFuc2Zvcm1fZmlsdGVycy5jYWxsKHNlbGYsIGZpbHRlcnMsIG9wdGlvbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh0eXBlb2Ygc2V0dGluZ3MudHJhbnNmb3JtX29wdGlvbnMgPT09ICdmdW5jdGlvbicpIHtcclxuICAgICAgb3B0aW9ucyA9IHNldHRpbmdzLnRyYW5zZm9ybV9vcHRpb25zLmNhbGwoc2VsZiwgZmlsdGVycywgb3B0aW9ucyk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGZpbHRlcnMubGVuZ3RoID4gMCkge1xyXG4gICAgICBpZiAoZmlsdGVycy5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgZmluZFF1ZXJ5LiRhbmQgPSBmaWx0ZXJzO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZpbmRRdWVyeSA9IGZpbHRlcnNbMF07XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBDb3VudHMucHVibGlzaChcclxuICAgICAgc2VsZixcclxuICAgICAgYHN1Yl9jb3VudF8ke3NlbGYuX3N1YnNjcmlwdGlvbklkfWAsXHJcbiAgICAgIGNvbGxlY3Rpb24uZmluZChmaW5kUXVlcnkpLFxyXG4gICAgICB7XHJcbiAgICAgICAgbm9SZWFkeTogdHJ1ZSxcclxuICAgICAgICBub25SZWFjdGl2ZTogIW9wdGlvbnMucmVhY3RpdmVcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAob3B0aW9ucy5kZWJ1Zykge1xyXG4gICAgICBjb25zb2xlLmxvZyhcclxuICAgICAgICAnUGFnaW5hdGlvbicsXHJcbiAgICAgICAgc2V0dGluZ3MubmFtZSxcclxuICAgICAgICBvcHRpb25zLnJlYWN0aXZlID8gJ3JlYWN0aXZlJyA6ICdub24tcmVhY3RpdmUnLFxyXG4gICAgICAgICdwdWJsaXNoJyxcclxuICAgICAgICBKU09OLnN0cmluZ2lmeShmaW5kUXVlcnkpLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KG9wdGlvbnMpXHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFvcHRpb25zLnJlYWN0aXZlKSB7XHJcbiAgICAgIGNvbnN0IGRvY3MgPSBjb2xsZWN0aW9uLmZpbmQoZmluZFF1ZXJ5LCBvcHRpb25zKS5mZXRjaCgpO1xyXG5cclxuICAgICAgXy5lYWNoKGRvY3MsIGZ1bmN0aW9uKGRvYykge1xyXG4gICAgICAgICAgICBzZWxmLmFkZGVkKGNvbGxlY3Rpb24uX25hbWUsIGRvYy5faWQsIGRvYyk7XHJcblxyXG4gICAgICAgICAgICBzZWxmLmNoYW5nZWQoY29sbGVjdGlvbi5fbmFtZSwgZG9jLl9pZCwge1tgc3ViXyR7c2VsZi5fc3Vic2NyaXB0aW9uSWR9YF06IDF9KTtcclxuICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGhhbmRsZSA9IGNvbGxlY3Rpb24uZmluZChmaW5kUXVlcnksIG9wdGlvbnMpLm9ic2VydmVDaGFuZ2VzKHtcclxuICAgICAgICAgICAgYWRkZWQoaWQsIGZpZWxkcykge1xyXG4gICAgICAgICAgICAgICAgc2VsZi5hZGRlZChjb2xsZWN0aW9uLl9uYW1lLCBpZCwgZmllbGRzKTtcclxuXHJcbiAgICAgICAgICAgICAgICBzZWxmLmNoYW5nZWQoY29sbGVjdGlvbi5fbmFtZSwgaWQsIHtbYHN1Yl8ke3NlbGYuX3N1YnNjcmlwdGlvbklkfWBdOiAxfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNoYW5nZWQoaWQsIGZpZWxkcykge1xyXG4gICAgICAgICAgICAgICAgc2VsZi5jaGFuZ2VkKGNvbGxlY3Rpb24uX25hbWUsIGlkLCBmaWVsZHMpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByZW1vdmVkKGlkKSB7XHJcbiAgICAgICAgICAgICAgICBzZWxmLnJlbW92ZWQoY29sbGVjdGlvbi5fbmFtZSwgaWQpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZWxmLm9uU3RvcCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGhhbmRsZS5zdG9wKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2VsZi5yZWFkeSgpO1xyXG4gIH0pO1xyXG59XHJcblxyXG5jbGFzcyBQYWdpbmF0aW9uRmFjdG9yeSB7XHJcbiAgY29uc3RydWN0b3IoY29sbGVjdGlvbiwgc2V0dGluZ3NJbikge1xyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG1heC1sZW5cclxuICAgIGNvbnNvbGUud2FybignRGVwcmVjYXRlZCB1c2Ugb2YgTWV0ZW9yLlBhZ2luYXRpb24uIE9uIHNlcnZlci1zaWRlIHVzZSBwdWJsaXNoUGFnaW5hdGlvbigpIGZ1bmN0aW9uLicpO1xyXG5cclxuICAgIHB1Ymxpc2hQYWdpbmF0aW9uKGNvbGxlY3Rpb24sIHNldHRpbmdzSW4pO1xyXG4gIH1cclxufVxyXG5cclxuTWV0ZW9yLlBhZ2luYXRpb24gPSBQYWdpbmF0aW9uRmFjdG9yeTtcclxuIl19
