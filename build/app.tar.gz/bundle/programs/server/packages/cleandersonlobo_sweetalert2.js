(function () {



/* Exports */
Package._define("cleandersonlobo:sweetalert2");

})();
