(function () {

/* Package-scope variables */
var BlazeLayout;



/* Exports */
Package._define("kadira:blaze-layout", {
  BlazeLayout: BlazeLayout
});

})();
